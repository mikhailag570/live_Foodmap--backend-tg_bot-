"""initial schema

Revision ID: 0001_initial
Revises:
Create Date: 2026-07-07

Hand-written to mirror app/models.py exactly (equivalent to what
`alembic revision --autogenerate` would produce against an empty DB).
Regenerate with autogenerate once the app can reach a package index in
your environment; diff it against this file before trusting it blindly.
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

fodmap_label_enum = sa.Enum("low", "moderate", "high", name="fodmaplabel")
product_status_enum = sa.Enum("predicted", "lab_verified", "user_submitted", name="productstatus")
product_source_enum = sa.Enum(
    "text_ml_model", "photo_ml_model", "manual_user_entry", "open_food_facts", "usda_fdc", "seed_dataset",
    name="productsource",
)
diet_phase_enum = sa.Enum(
    "elimination", "reintroduction", "personalisation", name="dietphase"
)  # SQLAlchemy's Enum type stores the member NAME by default, not the int value
fodmap_group_enum = sa.Enum("oligos", "fructose", "lactose", "polyols", name="fodmapgroup")
photo_status_enum = sa.Enum("pending", "processed", "failed", name="photoanalysisstatus")
meal_type_enum = sa.Enum("breakfast", "lunch", "dinner", "snack", name="mealtype")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(255), nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("is_superuser", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    op.create_table(
        "refresh_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_jti", sa.String(36), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])
    op.create_index("ix_refresh_tokens_token_jti", "refresh_tokens", ["token_jti"], unique=True)

    op.create_table(
        "products",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("barcode", sa.String(64), nullable=True),
        sa.Column("brand", sa.String(255), nullable=True),
        sa.Column("portion_size_g", sa.Float, nullable=False),
        sa.Column("oligos_g", sa.Float, nullable=True),
        sa.Column("oligos_label", fodmap_label_enum, nullable=False),
        sa.Column("fructose_g", sa.Float, nullable=True),
        sa.Column("fructose_label", fodmap_label_enum, nullable=False),
        sa.Column("lactose_g", sa.Float, nullable=True),
        sa.Column("lactose_label", fodmap_label_enum, nullable=False),
        sa.Column("polyols_g", sa.Float, nullable=True),
        sa.Column("polyols_label", fodmap_label_enum, nullable=False),
        sa.Column("overall_label", fodmap_label_enum, nullable=False),
        sa.Column("confidence", sa.Float, nullable=False),
        sa.Column("status", product_status_enum, nullable=False),
        sa.Column("source", product_source_enum, nullable=False),
        sa.Column("ingredients_text", sa.Text, nullable=True),
        sa.Column("submitted_by_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_products_name", "products", ["name"])
    op.create_index("ix_products_barcode", "products", ["barcode"], unique=True)

    op.create_table(
        "fodmap_measurements",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("group", fodmap_group_enum, nullable=False),
        sa.Column("grams_per_portion", sa.Float, nullable=True),
        sa.Column("label", fodmap_label_enum, nullable=False),
        sa.Column("confidence", sa.Float, nullable=False),
        sa.Column("source", product_source_enum, nullable=False),
        sa.Column("model_version", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_fodmap_measurements_product_id", "fodmap_measurements", ["product_id"])

    op.create_table(
        "recipes",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("instructions", sa.Text, nullable=False),
        sa.Column("portion_size_g", sa.Float, nullable=False),
        sa.Column("overall_label", fodmap_label_enum, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_recipes_name", "recipes", ["name"])

    op.create_table(
        "recipe_ingredients",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("recipe_id", sa.String(36), sa.ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("quantity_g", sa.Float, nullable=False),
        sa.UniqueConstraint("recipe_id", "product_id", name="uq_recipe_product"),
    )

    op.create_table(
        "photos",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("file_path", sa.String(512), nullable=False),
        sa.Column("content_type", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.Integer, nullable=False),
        sa.Column("status", photo_status_enum, nullable=False),
        sa.Column("predicted_label", sa.String(255), nullable=True),
        sa.Column("predicted_confidence", sa.Float, nullable=True),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=True),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_photos_user_id", "photos", ["user_id"])

    op.create_table(
        "meals",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=True),
        sa.Column("recipe_id", sa.String(36), sa.ForeignKey("recipes.id"), nullable=True),
        sa.Column("meal_type", meal_type_enum, nullable=False),
        sa.Column("quantity_g", sa.Float, nullable=False),
        sa.Column("eaten_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("notes", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_meals_user_id", "meals", ["user_id"])

    op.create_table(
        "symptoms",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("symptom_type", sa.String(100), nullable=False),
        sa.Column("severity", sa.Integer, nullable=False),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("notes", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_symptoms_user_id", "symptoms", ["user_id"])

    op.create_table(
        "diet_phase_states",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("phase", diet_phase_enum, nullable=False),
        sa.Column("phase_started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("current_reintro_group", fodmap_group_enum, nullable=True),
        sa.Column("completed_reintro_groups", sa.String(255), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("user_id", name="uq_diet_phase_states_user_id"),
    )

    op.create_table(
        "planner_plans",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("phase", diet_phase_enum, nullable=False),
        sa.Column("week_start", sa.DateTime(timezone=True), nullable=False),
        sa.Column("plan_json", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_planner_plans_user_id", "planner_plans", ["user_id"])


def downgrade() -> None:
    op.drop_table("planner_plans")
    op.drop_table("diet_phase_states")
    op.drop_table("symptoms")
    op.drop_table("meals")
    op.drop_table("photos")
    op.drop_table("recipe_ingredients")
    op.drop_table("recipes")
    op.drop_table("fodmap_measurements")
    op.drop_table("products")
    op.drop_table("refresh_tokens")
    op.drop_table("users")

    fodmap_label_enum.drop(op.get_bind(), checkfirst=True)
    product_status_enum.drop(op.get_bind(), checkfirst=True)
    product_source_enum.drop(op.get_bind(), checkfirst=True)
    diet_phase_enum.drop(op.get_bind(), checkfirst=True)
    fodmap_group_enum.drop(op.get_bind(), checkfirst=True)
    photo_status_enum.drop(op.get_bind(), checkfirst=True)
    meal_type_enum.drop(op.get_bind(), checkfirst=True)
