"""
app/auth.py

Full JWT authentication:
- Password hashing (bcrypt via passlib).
- Access tokens (short-lived, used on every request).
- Refresh tokens (long-lived, persisted in DB by jti so they can be
  revoked individually; rotated on every /auth/refresh call).
- FastAPI dependencies: get_current_user / get_current_active_user, used
  by every protected route.
"""
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models import RefreshToken, User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# tokenUrl just documents where a client obtains a token, for the
# OpenAPI/Swagger UI "Authorize" button - the actual route is /auth/login.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)


# --------------------------------------------------------------------------- #
# Password hashing
# --------------------------------------------------------------------------- #

def hash_password(plain_password: str) -> str:
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# --------------------------------------------------------------------------- #
# Token creation
# --------------------------------------------------------------------------- #

def _create_token(subject: str, expires_delta: timedelta, token_type: str, jti: Optional[str] = None) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": subject,
        "type": token_type,
        "iat": now,
        "exp": now + expires_delta,
        "jti": jti or str(uuid.uuid4()),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_access_token(user_id: str) -> str:
    return _create_token(
        subject=user_id,
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
        token_type="access",
    )


def create_refresh_token(db: Session, user_id: str) -> str:
    jti = str(uuid.uuid4())
    expires_delta = timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    token = _create_token(subject=user_id, expires_delta=expires_delta, token_type="refresh", jti=jti)

    db.add(RefreshToken(
        user_id=user_id,
        token_jti=jti,
        expires_at=datetime.now(timezone.utc) + expires_delta,
    ))
    db.commit()
    return token


def issue_token_pair(db: Session, user_id: str) -> tuple[str, str]:
    return create_access_token(user_id), create_refresh_token(db, user_id)


# --------------------------------------------------------------------------- #
# Token verification
# --------------------------------------------------------------------------- #

def _decode_token(token: str, expected_type: str) -> dict:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
    except JWTError:
        raise credentials_exception

    if payload.get("type") != expected_type:
        raise credentials_exception
    if payload.get("sub") is None:
        raise credentials_exception
    return payload


def rotate_refresh_token(db: Session, refresh_token: str) -> tuple[str, str]:
    """
    Verify a refresh token, revoke it, and issue a brand-new access +
    refresh pair (rotation prevents indefinite reuse of a leaked refresh
    token).
    """
    payload = _decode_token(refresh_token, expected_type="refresh")
    user_id = payload["sub"]
    jti = payload["jti"]

    stored = db.query(RefreshToken).filter(RefreshToken.token_jti == jti).first()
    if stored is None or stored.revoked:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token has been revoked")
    if stored.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token has expired")

    stored.revoked = True
    db.add(stored)
    db.commit()

    return issue_token_pair(db, user_id)


def revoke_refresh_token(db: Session, refresh_token: str) -> None:
    try:
        payload = _decode_token(refresh_token, expected_type="refresh")
    except HTTPException:
        return  # already invalid; nothing to do
    stored = db.query(RefreshToken).filter(RefreshToken.token_jti == payload["jti"]).first()
    if stored is not None:
        stored.revoked = True
        db.add(stored)
        db.commit()


# --------------------------------------------------------------------------- #
# FastAPI dependencies
# --------------------------------------------------------------------------- #

def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    if token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    payload = _decode_token(token, expected_type="access")
    user = db.query(User).filter(User.id == payload["sub"]).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user


def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Inactive user")
    return current_user
