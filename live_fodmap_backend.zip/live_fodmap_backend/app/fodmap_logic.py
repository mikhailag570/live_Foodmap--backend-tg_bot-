"""
app/fodmap_logic.py

Business rules from TZ section 2 and 3.1:

  "модели 1 и 2 - это системы оценки с уверенностью (confidence), а не
   измерения. Любой автоматически сгенерированный профиль должен
   проходить порог соответствия и если проходит этот порог, то
   добавляется в базу."

This module is the single place that:
  1. Turns a raw grams-per-portion value into a low/moderate/high label
     for one FODMAP subgroup (`classify_group`).
  2. Combines the 4 subgroup labels into one overall product label
     (`compute_overall_label`) - "worst group wins", which is the
     standard Monash-style convention (a product is only low-FODMAP
     overall if every subgroup is low).
  3. Decides, given a confidence score, whether an ML-predicted product
     may be auto-published to the shared catalogue, needs to be shown to
     the user as "unverified", or should be rejected outright
     (`decide_publication`).

Keeping this logic out of the route handlers means the same rules apply
identically whether the profile came from the text model, the photo
model, an Open Food Facts sync, or a manual correction.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from app.config import settings
from app.models import FodmapGroup, FodmapLabel, ProductStatus

_LABEL_ORDER = {FodmapLabel.low: 0, FodmapLabel.moderate: 1, FodmapLabel.high: 2}


def classify_group(group: FodmapGroup, grams_per_portion: Optional[float]) -> FodmapLabel:
    """
    Map a raw gram value for one FODMAP subgroup to a traffic-light label,
    using the thresholds in Settings.FODMAP_THRESHOLDS_G.

    If no gram estimate is available (grams_per_portion is None - some ML
    predictions only output a label directly), the caller should not use
    this function and should instead trust the model's own label output.
    """
    if grams_per_portion is None:
        raise ValueError("grams_per_portion is required to classify a group; "
                          "if the model only returns a label, use that label directly.")
    if grams_per_portion < 0:
        raise ValueError("grams_per_portion must be >= 0")

    thresholds = settings.FODMAP_THRESHOLDS_G[group.value]
    if grams_per_portion < thresholds["low"]:
        return FodmapLabel.low
    if grams_per_portion < thresholds["moderate"]:
        return FodmapLabel.moderate
    return FodmapLabel.high


def compute_overall_label(
    oligos: FodmapLabel, fructose: FodmapLabel, lactose: FodmapLabel, polyols: FodmapLabel
) -> FodmapLabel:
    """Overall label = the worst (highest) of the 4 subgroup labels."""
    worst = max([oligos, fructose, lactose, polyols], key=lambda lbl: _LABEL_ORDER[lbl])
    return worst


class PublicationDecision(str, Enum):
    auto_publish = "auto_publish"          # confidence high enough -> status=predicted, visible to all
    needs_confirmation = "needs_confirmation"  # confidence too low -> keep as user_submitted / review-only
    inconclusive = "inconclusive"          # confidence far too low -> don't store at all, ask user to retry


@dataclass
class PublicationResult:
    decision: PublicationDecision
    status: Optional[ProductStatus]  # None when inconclusive (nothing is stored)
    message: str


def decide_publication(confidence: float) -> PublicationResult:
    """
    Confidence-gated publication decision (TZ section 2).

    - confidence >= ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD:
        auto-publish as status=predicted, immediately visible/searchable
        by all users in the shared product catalogue.
    - ML_CONFIDENCE_MIN_USABLE_THRESHOLD <= confidence < AUTO_PUBLISH:
        store it, but as status=user_submitted (i.e. treated exactly
        like a manual, unverified entry) and scoped to the requesting
        user until a human confirms/corrects it.
    - confidence < ML_CONFIDENCE_MIN_USABLE_THRESHOLD:
        too unreliable to be useful; don't persist a product record at
        all, tell the user the prediction was inconclusive and ask them
        to submit the product manually or retake the photo.
    """
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be in [0, 1]")

    if confidence >= settings.ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD:
        return PublicationResult(
            decision=PublicationDecision.auto_publish,
            status=ProductStatus.predicted,
            message=(
                f"Confidence {confidence:.2f} meets the auto-publish threshold "
                f"({settings.ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD}); product added to the shared catalogue."
            ),
        )

    if confidence >= settings.ML_CONFIDENCE_MIN_USABLE_THRESHOLD:
        return PublicationResult(
            decision=PublicationDecision.needs_confirmation,
            status=ProductStatus.user_submitted,
            message=(
                f"Confidence {confidence:.2f} is below the auto-publish threshold "
                f"({settings.ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD}); saved as unverified "
                "and will need confirmation before it appears for other users."
            ),
        )

    return PublicationResult(
        decision=PublicationDecision.inconclusive,
        status=None,
        message=(
            f"Confidence {confidence:.2f} is below the minimum usable threshold "
            f"({settings.ML_CONFIDENCE_MIN_USABLE_THRESHOLD}); prediction discarded. "
            "Please try a clearer photo/description or enter the product manually."
        ),
    )


def promote_to_lab_verified(current_status: ProductStatus) -> ProductStatus:
    """
    Explicit state-transition helper. Only lab-verification workflows
    (e.g. an admin confirming against the Monash DB or a published
    composition table) may set status=lab_verified; this is never done
    implicitly by an ML prediction or a user submission.
    """
    return ProductStatus.lab_verified
