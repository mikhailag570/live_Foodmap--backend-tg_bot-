"""
app/external/openfoodfacts.py

Client for Open Food Facts (TZ 3.2: "ключевой источник для задачи 2
(упакованные товары) и для фичей ингредиентного состава").

Exposes barcode lookup and ingredient-text search. Network calls use
httpx with a short timeout and never raise on a miss - callers get None
and decide what to do (e.g. fall back to the text/photo ML models).
"""
from typing import Optional

import httpx

from app.config import settings


class OpenFoodFactsClient:
    def __init__(self):
        self._base_url = settings.OPEN_FOOD_FACTS_BASE_URL
        self._headers = {"User-Agent": settings.OPEN_FOOD_FACTS_USER_AGENT}
        self._timeout = settings.EXTERNAL_HTTP_TIMEOUT_SECONDS

    async def get_product_by_barcode(self, barcode: str) -> Optional[dict]:
        """
        Returns a normalised dict: {name, brand, ingredients_text,
        nutriments, portion_size_g} or None if not found / on error.
        """
        url = f"{self._base_url}/api/v2/product/{barcode}.json"
        try:
            async with httpx.AsyncClient(timeout=self._timeout, headers=self._headers) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json()
        except (httpx.HTTPError, ValueError):
            return None

        if data.get("status") != 1:
            return None

        product = data.get("product", {})
        serving_size_g = _parse_serving_size_g(product.get("serving_size"))

        return {
            "name": product.get("product_name") or product.get("generic_name") or "Unknown product",
            "brand": product.get("brands"),
            "ingredients_text": product.get("ingredients_text") or product.get("ingredients_text_en"),
            "nutriments": product.get("nutriments", {}),
            "portion_size_g": serving_size_g or 100.0,
            "barcode": barcode,
        }

    async def search_by_name(self, query: str, page_size: int = 5) -> list[dict]:
        url = f"{self._base_url}/cgi/search.pl"
        params = {
            "search_terms": query,
            "search_simple": 1,
            "action": "process",
            "json": 1,
            "page_size": page_size,
        }
        try:
            async with httpx.AsyncClient(timeout=self._timeout, headers=self._headers) as client:
                resp = await client.get(url, params=params)
                resp.raise_for_status()
                data = resp.json()
        except (httpx.HTTPError, ValueError):
            return []

        results = []
        for product in data.get("products", []):
            results.append({
                "name": product.get("product_name") or "Unknown product",
                "brand": product.get("brands"),
                "barcode": product.get("code"),
                "ingredients_text": product.get("ingredients_text"),
            })
        return results


def _parse_serving_size_g(serving_size: Optional[str]) -> Optional[float]:
    """OFF serving_size is a free-text field like '30 g' or '250ml'."""
    if not serving_size:
        return None
    digits = "".join(ch for ch in serving_size if ch.isdigit() or ch == ".")
    try:
        return float(digits) if digits else None
    except ValueError:
        return None


_client_singleton: Optional[OpenFoodFactsClient] = None


def get_open_food_facts_client() -> OpenFoodFactsClient:
    global _client_singleton
    if _client_singleton is None:
        _client_singleton = OpenFoodFactsClient()
    return _client_singleton
