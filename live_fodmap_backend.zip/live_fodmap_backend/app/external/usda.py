"""
app/external/usda.py

Client for USDA FoodData Central (TZ 3.2: "нутриентный состав, для
фичей."). Used to enrich a product with nutrient features (fibre,
sugars, etc.) that feed the text/photo FODMAP models as inputs - USDA
does NOT provide FODMAP-specific data itself, only general nutrient
composition.
"""
from typing import Optional

import httpx

from app.config import settings


class UsdaFdcClient:
    def __init__(self):
        self._base_url = settings.USDA_FDC_BASE_URL
        self._api_key = settings.USDA_FDC_API_KEY
        self._timeout = settings.EXTERNAL_HTTP_TIMEOUT_SECONDS

    async def search_food(self, query: str, page_size: int = 5) -> list[dict]:
        url = f"{self._base_url}/foods/search"
        params = {"api_key": self._api_key, "query": query, "pageSize": page_size}
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(url, params=params)
                resp.raise_for_status()
                data = resp.json()
        except (httpx.HTTPError, ValueError):
            return []

        results = []
        for food in data.get("foods", []):
            results.append({
                "fdc_id": food.get("fdcId"),
                "description": food.get("description"),
                "nutrients": {
                    n.get("nutrientName"): n.get("value")
                    for n in food.get("foodNutrients", [])
                    if n.get("nutrientName")
                },
            })
        return results

    async def get_food_by_id(self, fdc_id: int) -> Optional[dict]:
        url = f"{self._base_url}/food/{fdc_id}"
        params = {"api_key": self._api_key}
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(url, params=params)
                resp.raise_for_status()
                data = resp.json()
        except (httpx.HTTPError, ValueError):
            return None

        return {
            "fdc_id": data.get("fdcId"),
            "description": data.get("description"),
            "nutrients": {
                n.get("nutrient", {}).get("name"): n.get("amount")
                for n in data.get("foodNutrients", [])
                if n.get("nutrient", {}).get("name")
            },
        }


_client_singleton: Optional[UsdaFdcClient] = None


def get_usda_client() -> UsdaFdcClient:
    global _client_singleton
    if _client_singleton is None:
        _client_singleton = UsdaFdcClient()
    return _client_singleton
