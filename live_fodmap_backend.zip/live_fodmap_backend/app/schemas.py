"""
app/schemas.py

Pydantic v2 schemas used for request validation and response
serialisation. Kept separate from the ORM models (app/models.py) so the
API contract can evolve independently of the DB schema.
"""
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import (
    DietPhase,
    FodmapGroup,
    FodmapLabel,
    MealType,
    PhotoAnalysisStatus,
    ProductSource,
    ProductStatus,
)


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #

class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    full_name: Optional[str] = None
    is_active: bool
    created_at: datetime


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


# --------------------------------------------------------------------------- #
# FODMAP profile
# --------------------------------------------------------------------------- #

class FodmapGroupResult(BaseModel):
    label: FodmapLabel
    grams_per_portion: Optional[float] = None
    confidence: float


class FodmapProfile(BaseModel):
    portion_size_g: float
    oligos: FodmapGroupResult
    fructose: FodmapGroupResult
    lactose: FodmapGroupResult
    polyols: FodmapGroupResult
    overall_label: FodmapLabel
    overall_confidence: float


# --------------------------------------------------------------------------- #
# Products
# --------------------------------------------------------------------------- #

class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    barcode: Optional[str] = None
    brand: Optional[str] = None
    portion_size_g: float
    oligos_g: Optional[float]
    oligos_label: FodmapLabel
    fructose_g: Optional[float]
    fructose_label: FodmapLabel
    lactose_g: Optional[float]
    lactose_label: FodmapLabel
    polyols_g: Optional[float]
    polyols_label: FodmapLabel
    overall_label: FodmapLabel
    confidence: float
    status: ProductStatus
    source: ProductSource
    created_at: datetime


class ProductManualSubmit(BaseModel):
    """User manually entering / correcting a product -> always status=user_submitted."""
    name: str
    barcode: Optional[str] = None
    brand: Optional[str] = None
    portion_size_g: float = Field(gt=0)
    oligos_g: Optional[float] = Field(default=None, ge=0)
    fructose_g: Optional[float] = Field(default=None, ge=0)
    lactose_g: Optional[float] = Field(default=None, ge=0)
    polyols_g: Optional[float] = Field(default=None, ge=0)


class TextPredictRequest(BaseModel):
    """Task 1 from the TZ: user types a product name/description."""
    query: str = Field(min_length=2, max_length=500)
    portion_size_g: Optional[float] = Field(default=None, gt=0)


class TextPredictResponse(BaseModel):
    product: ProductOut
    published: bool
    message: str


# --------------------------------------------------------------------------- #
# Photo analysis (Task 2 from the TZ)
# --------------------------------------------------------------------------- #

class PhotoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    status: PhotoAnalysisStatus
    predicted_label: Optional[str]
    predicted_confidence: Optional[float]
    product_id: Optional[str]
    error_message: Optional[str]
    created_at: datetime


class PhotoAnalyzeResponse(BaseModel):
    photo: PhotoOut
    product: Optional[ProductOut] = None
    published: bool
    message: str


# --------------------------------------------------------------------------- #
# Meals / symptoms
# --------------------------------------------------------------------------- #

class MealCreate(BaseModel):
    product_id: Optional[str] = None
    recipe_id: Optional[str] = None
    meal_type: MealType
    quantity_g: float = Field(gt=0)
    eaten_at: Optional[datetime] = None
    notes: Optional[str] = None


class MealOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    product_id: Optional[str]
    recipe_id: Optional[str]
    meal_type: MealType
    quantity_g: float
    eaten_at: datetime
    notes: Optional[str]


class SymptomCreate(BaseModel):
    symptom_type: str = Field(min_length=2, max_length=100)
    severity: int = Field(ge=1, le=10)
    recorded_at: Optional[datetime] = None
    notes: Optional[str] = None


class SymptomOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    symptom_type: str
    severity: int
    recorded_at: datetime
    notes: Optional[str]


# --------------------------------------------------------------------------- #
# Diet phase
# --------------------------------------------------------------------------- #

class DietPhaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    phase: DietPhase
    phase_started_at: datetime
    current_reintro_group: Optional[FodmapGroup]
    completed_reintro_groups: Optional[str]


class AdvancePhaseRequest(BaseModel):
    """Used when moving 1->2 (no group needed), or advancing within
    phase 2 to the next FODMAP group to challenge."""
    next_reintro_group: Optional[FodmapGroup] = None


# --------------------------------------------------------------------------- #
# Planner (Task 3 from the TZ)
# --------------------------------------------------------------------------- #

class PlannerGenerateRequest(BaseModel):
    week_start: Optional[datetime] = None
    preferences: Optional[dict] = None  # free-form: dislikes, allergies, cuisine, etc.


class PlannerPlanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    phase: DietPhase
    week_start: datetime
    plan: dict
    created_at: datetime
