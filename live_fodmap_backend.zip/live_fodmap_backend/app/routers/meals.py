"""app/routers/meals.py - meal tracking CRUD (list + create)."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.models import Meal, Product, Recipe, User
from app.schemas import MealCreate, MealOut

router = APIRouter(prefix="/meals", tags=["meals"])


@router.post("", response_model=MealOut, status_code=status.HTTP_201_CREATED)
def add_meal(
    payload: MealCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    if not payload.product_id and not payload.recipe_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Provide product_id or recipe_id")
    if payload.product_id and payload.recipe_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Provide only one of product_id/recipe_id")

    if payload.product_id and db.query(Product).filter(Product.id == payload.product_id).first() is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
    if payload.recipe_id and db.query(Recipe).filter(Recipe.id == payload.recipe_id).first() is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recipe not found")

    meal = Meal(
        user_id=current_user.id,
        product_id=payload.product_id,
        recipe_id=payload.recipe_id,
        meal_type=payload.meal_type,
        quantity_g=payload.quantity_g,
        eaten_at=payload.eaten_at or datetime.now(timezone.utc),
        notes=payload.notes,
    )
    db.add(meal)
    db.commit()
    db.refresh(meal)
    return meal


@router.get("", response_model=list[MealOut])
def list_meals(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    limit: int = 50,
    offset: int = 0,
):
    return (
        db.query(Meal)
        .filter(Meal.user_id == current_user.id)
        .order_by(Meal.eaten_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
