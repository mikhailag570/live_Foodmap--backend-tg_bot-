"""
app/routers/photo.py

POST /photo/analyze - Task 2 from the TZ: upload a photo, run it
through the vision/FODMAP pipeline, apply the same confidence gate as
the text model, and persist both the Photo record (audit trail) and,
if the confidence allows it, a new/updated Product.
"""
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.fodmap_logic import PublicationDecision, compute_overall_label, decide_publication
from app.ml.photo_classifier import PhotoFodmapClassifier, get_photo_classifier
from app.models import Photo, PhotoAnalysisStatus, Product, ProductSource, User
from app.schemas import PhotoAnalyzeResponse, PhotoOut, ProductOut
from app.storage import save_photo

router = APIRouter(prefix="/photo", tags=["photo"])


@router.post("/analyze", response_model=PhotoAnalyzeResponse, status_code=status.HTTP_201_CREATED)
async def analyze_photo(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    classifier: PhotoFodmapClassifier = Depends(get_photo_classifier),
):
    relative_path, size_bytes = await save_photo(file, current_user.id)

    photo = Photo(
        user_id=current_user.id,
        file_path=relative_path,
        content_type=file.content_type,
        size_bytes=size_bytes,
        status=PhotoAnalysisStatus.pending,
    )
    db.add(photo)
    db.commit()
    db.refresh(photo)

    try:
        from app.storage import read_photo_bytes
        image_bytes = read_photo_bytes(relative_path)
        result = classifier.predict(image_bytes, file.content_type)
    except Exception as exc:  # pragma: no cover - defensive; a real vision
        # model call can fail for many reasons (timeout, bad image, OOM).
        photo.status = PhotoAnalysisStatus.failed
        photo.error_message = str(exc)
        db.add(photo)
        db.commit()
        db.refresh(photo)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Photo recognition failed; please retry with a clearer image.",
        )

    photo.predicted_label = result.predicted_label
    photo.predicted_confidence = result.overall_confidence

    decision = decide_publication(result.overall_confidence)

    if decision.decision == PublicationDecision.inconclusive or result.fodmap_prediction is None:
        photo.status = PhotoAnalysisStatus.processed
        db.add(photo)
        db.commit()
        db.refresh(photo)
        return PhotoAnalyzeResponse(
            photo=PhotoOut.model_validate(photo),
            product=None,
            published=False,
            message=decision.message,
        )

    prediction = result.fodmap_prediction
    overall_label = compute_overall_label(
        prediction.oligos.label, prediction.fructose.label, prediction.lactose.label, prediction.polyols.label
    )

    product = Product(
        name=result.predicted_label,
        portion_size_g=prediction.portion_size_g,
        oligos_g=prediction.oligos.grams_per_portion,
        oligos_label=prediction.oligos.label,
        fructose_g=prediction.fructose.grams_per_portion,
        fructose_label=prediction.fructose.label,
        lactose_g=prediction.lactose.grams_per_portion,
        lactose_label=prediction.lactose.label,
        polyols_g=prediction.polyols.grams_per_portion,
        polyols_label=prediction.polyols.label,
        overall_label=overall_label,
        confidence=result.overall_confidence,
        status=decision.status,
        source=ProductSource.photo_ml_model,
        submitted_by_id=current_user.id,
    )
    db.add(product)
    db.flush()

    photo.status = PhotoAnalysisStatus.processed
    photo.product_id = product.id
    db.add(photo)
    db.commit()
    db.refresh(photo)
    db.refresh(product)

    return PhotoAnalyzeResponse(
        photo=PhotoOut.model_validate(photo),
        product=ProductOut.model_validate(product),
        published=decision.decision == PublicationDecision.auto_publish,
        message=decision.message,
    )
