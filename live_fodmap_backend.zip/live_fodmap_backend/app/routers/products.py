"""
app/routers/products.py

- GET /products/{name}        - lookup by name in the local catalogue,
                                 falling back to Open Food Facts search.
- POST /products              - manual/user_submitted product entry.
- POST /products/predict-text - Task 1: text -> FODMAP profile via the
                                 ML text classifier, confidence-gated.
- POST /products/{id}/verify  - promote a product to lab_verified
                                 (superuser only - explicit human/lab
                                 confirmation, never automatic).
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.external.openfoodfacts import get_open_food_facts_client
from app.fodmap_logic import (
    PublicationDecision,
    compute_overall_label,
    decide_publication,
    promote_to_lab_verified,
)
from app.ml.text_classifier import TextFodmapClassifier, get_text_classifier
from app.models import (
    FodmapGroup,
    FodmapLabel,
    Product,
    ProductSource,
    ProductStatus,
    User,
)
from app.schemas import ProductManualSubmit, ProductOut, TextPredictRequest, TextPredictResponse

router = APIRouter(prefix="/products", tags=["products"])


@router.get("/{name}", response_model=ProductOut)
async def get_product(name: str, db: Session = Depends(get_db)):
    from sqlalchemy import case

    product = (
        db.query(Product)
        .filter(Product.name.ilike(f"%{name}%"))
        # Prefer lab_verified, then predicted, then user_submitted.
        .order_by(
            case(
                (Product.status == ProductStatus.lab_verified, 0),
                (Product.status == ProductStatus.predicted, 1),
                else_=2,
            )
        )
        .first()
    )
    if product is not None:
        return product

    # Not in the local catalogue - try Open Food Facts as a fallback
    # search source (TZ 3.2), but do NOT persist it here; that only
    # happens through an explicit predict/submit call so confidence
    # gating is always applied.
    off_results = await get_open_food_facts_client().search_by_name(name, page_size=1)
    if off_results:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Not in local catalogue yet, but found on Open Food Facts: "
                f"'{off_results[0]['name']}'. Submit it via POST /products or "
                f"/products/predict-text to add it."
            ),
        )
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")


@router.post("", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
def submit_product(
    payload: ProductManualSubmit,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Manual entry/correction by a user. Always stored as user_submitted -
    a human is asserting these values, but they aren't lab-verified."""
    from app.fodmap_logic import classify_group

    def label_or_low(group: FodmapGroup, grams):
        return classify_group(group, grams) if grams is not None else FodmapLabel.low

    oligos_label = label_or_low(FodmapGroup.oligos, payload.oligos_g)
    fructose_label = label_or_low(FodmapGroup.fructose, payload.fructose_g)
    lactose_label = label_or_low(FodmapGroup.lactose, payload.lactose_g)
    polyols_label = label_or_low(FodmapGroup.polyols, payload.polyols_g)

    overall = compute_overall_label(oligos_label, fructose_label, lactose_label, polyols_label)

    product = Product(
        name=payload.name,
        barcode=payload.barcode,
        brand=payload.brand,
        portion_size_g=payload.portion_size_g,
        oligos_g=payload.oligos_g,
        oligos_label=oligos_label,
        fructose_g=payload.fructose_g,
        fructose_label=fructose_label,
        lactose_g=payload.lactose_g,
        lactose_label=lactose_label,
        polyols_g=payload.polyols_g,
        polyols_label=polyols_label,
        overall_label=overall,
        confidence=1.0,  # human-entered value, not a model estimate
        status=ProductStatus.user_submitted,
        source=ProductSource.manual_user_entry,
        submitted_by_id=current_user.id,
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


@router.post("/predict-text", response_model=TextPredictResponse)
def predict_text(
    payload: TextPredictRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    classifier: TextFodmapClassifier = Depends(get_text_classifier),
):
    prediction = classifier.predict(payload.query, payload.portion_size_g)

    decision = decide_publication(prediction.overall_confidence)
    if decision.decision == PublicationDecision.inconclusive:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=decision.message)

    overall_label = compute_overall_label(
        prediction.oligos.label, prediction.fructose.label, prediction.lactose.label, prediction.polyols.label
    )

    product = Product(
        name=payload.query,
        portion_size_g=prediction.portion_size_g,
        oligos_g=prediction.oligos.grams_per_portion,
        oligos_label=prediction.oligos.label,
        fructose_g=prediction.fructose.grams_per_portion,
        fructose_label=prediction.fructose.label,
        lactose_g=prediction.lactose.grams_per_portion,
        lactose_label=prediction.lactose.label,
        polyols_g=prediction.polyols.grams_per_portion,
        polyols_label=prediction.polyols.label,
        overall_label=overall_label,
        confidence=prediction.overall_confidence,
        status=decision.status,
        source=ProductSource.text_ml_model,
        submitted_by_id=current_user.id,
    )
    db.add(product)
    db.commit()
    db.refresh(product)

    return TextPredictResponse(
        product=product,
        published=decision.decision == PublicationDecision.auto_publish,
        message=decision.message,
    )


@router.post("/{product_id}/verify", response_model=ProductOut)
def verify_product(
    product_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    if not current_user.is_superuser:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only lab reviewers can verify products")

    product = db.query(Product).filter(Product.id == product_id).first()
    if product is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

    product.status = promote_to_lab_verified(product.status)
    db.add(product)
    db.commit()
    db.refresh(product)
    return product
