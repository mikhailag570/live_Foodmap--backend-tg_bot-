"""
app/routers/planner.py

POST /planner/generate - Task 3: build a personalised meal plan given
the user's current diet phase (and, in phase 2, which FODMAP group is
being challenged) plus free-form preferences.
"""
import json
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.ml.meal_planner import MealPlanner, get_meal_planner
from app.models import DietPhaseState, PlannerPlan, User
from app.schemas import PlannerGenerateRequest, PlannerPlanOut
from app.routers.diet_phase import get_or_create_diet_phase_state

router = APIRouter(prefix="/planner", tags=["planner"])


def _default_week_start() -> datetime:
    now = datetime.now(timezone.utc)
    monday = now - timedelta(days=now.weekday())
    return monday.replace(hour=0, minute=0, second=0, microsecond=0)


@router.post("/generate", response_model=PlannerPlanOut)
def generate_plan(
    payload: PlannerGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    planner: MealPlanner = Depends(get_meal_planner),
):
    phase_state = get_or_create_diet_phase_state(db, current_user)
    week_start = payload.week_start or _default_week_start()

    generated = planner.generate(
        db=db,
        phase=phase_state.phase,
        current_reintro_group=phase_state.current_reintro_group,
        preferences=payload.preferences,
        week_start=week_start,
    )

    plan = PlannerPlan(
        user_id=current_user.id,
        phase=phase_state.phase,
        week_start=week_start,
        plan_json=json.dumps(generated.to_json_dict()),
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)

    return PlannerPlanOut(
        id=plan.id,
        phase=plan.phase,
        week_start=plan.week_start,
        plan=json.loads(plan.plan_json),
        created_at=plan.created_at,
    )


@router.get("", response_model=list[PlannerPlanOut])
def list_plans(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    limit: int = 10,
):
    plans = (
        db.query(PlannerPlan)
        .filter(PlannerPlan.user_id == current_user.id)
        .order_by(PlannerPlan.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        PlannerPlanOut(
            id=p.id, phase=p.phase, week_start=p.week_start, plan=json.loads(p.plan_json), created_at=p.created_at
        )
        for p in plans
    ]
