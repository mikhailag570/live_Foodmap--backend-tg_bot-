"""app/routers/symptoms.py - symptom tracking CRUD (list + create)."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.models import Symptom, User
from app.schemas import SymptomCreate, SymptomOut

router = APIRouter(prefix="/symptoms", tags=["symptoms"])


@router.post("", response_model=SymptomOut, status_code=status.HTTP_201_CREATED)
def add_symptom(
    payload: SymptomCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    symptom = Symptom(
        user_id=current_user.id,
        symptom_type=payload.symptom_type,
        severity=payload.severity,
        recorded_at=payload.recorded_at or datetime.now(timezone.utc),
        notes=payload.notes,
    )
    db.add(symptom)
    db.commit()
    db.refresh(symptom)
    return symptom


@router.get("", response_model=list[SymptomOut])
def list_symptoms(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    limit: int = 50,
    offset: int = 0,
):
    return (
        db.query(Symptom)
        .filter(Symptom.user_id == current_user.id)
        .order_by(Symptom.recorded_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
