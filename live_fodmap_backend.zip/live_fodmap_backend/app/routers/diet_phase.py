"""
app/routers/diet_phase.py

Tracks and advances a user's position in the 3-phase Low-FODMAP
protocol described in the TZ addendum:
  1 = elimination      (minimise all 4 groups)
  2 = reintroduction   (challenge one group per week)
  3 = personalisation  (all groups reintroduced per individual tolerance)
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.database import get_db
from app.models import DietPhase, DietPhaseState, FodmapGroup, User
from app.schemas import AdvancePhaseRequest, DietPhaseOut

router = APIRouter(prefix="/diet-phase", tags=["diet-phase"])


def get_or_create_diet_phase_state(db: Session, user: User) -> DietPhaseState:
    state = db.query(DietPhaseState).filter(DietPhaseState.user_id == user.id).first()
    if state is None:
        state = DietPhaseState(user_id=user.id, phase=DietPhase.elimination)
        db.add(state)
        db.commit()
        db.refresh(state)
    return state


@router.get("", response_model=DietPhaseOut)
def get_phase(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return get_or_create_diet_phase_state(db, current_user)


@router.post("/advance", response_model=DietPhaseOut)
def advance_phase(
    payload: AdvancePhaseRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """
    1 -> 2: moves to reintroduction; `next_reintro_group` must be given
            (which of the 4 groups to challenge in week 1).
    2 -> 2: still in reintroduction, but moving to the next group after
            finishing a week with the previous one; `next_reintro_group`
            required, must not repeat an already-completed group.
    2 -> 3: once all 4 groups have been challenged, omit
            `next_reintro_group` to move into personalisation.
    3:      terminal state; nothing to advance to.
    """
    state = get_or_create_diet_phase_state(db, current_user)

    if state.phase == DietPhase.elimination:
        if payload.next_reintro_group is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="next_reintro_group is required to start phase 2 (reintroduction)",
            )
        state.phase = DietPhase.reintroduction
        state.current_reintro_group = payload.next_reintro_group
        state.completed_reintro_groups = ""

    elif state.phase == DietPhase.reintroduction:
        completed = set(filter(None, (state.completed_reintro_groups or "").split(",")))
        if state.current_reintro_group is not None:
            completed.add(state.current_reintro_group.value)

        if payload.next_reintro_group is None:
            # Only allowed once all 4 groups have been challenged.
            if len(completed) < len(FodmapGroup):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Cannot move to phase 3 yet: {len(completed)}/{len(FodmapGroup)} "
                        "groups challenged. Provide next_reintro_group to continue phase 2."
                    ),
                )
            state.phase = DietPhase.personalisation
            state.current_reintro_group = None
        else:
            if payload.next_reintro_group.value in completed:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Group '{payload.next_reintro_group.value}' was already challenged",
                )
            state.current_reintro_group = payload.next_reintro_group

        state.completed_reintro_groups = ",".join(sorted(completed))

    else:  # personalisation
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Already in the final phase")

    state.phase_started_at = datetime.now(timezone.utc)
    db.add(state)
    db.commit()
    db.refresh(state)
    return state
