"""
app/ml/text_classifier.py

Task 1 from the TZ: "Текстовое определение FODMAP-профиля" - the user
types a product name/description, the model returns a 4-group FODMAP
profile with confidence.

This module defines the STABLE INTERFACE the rest of the backend talks
to (`TextFodmapClassifier.predict`). The body below is a placeholder
heuristic (keyword/seed-dataset lookup) so the API is runnable end to
end before the real model exists. Swap `HeuristicTextFodmapClassifier`
for a real implementation (e.g. a fine-tuned transformer, or a call out
to a separate model-serving process) without touching any router code -
only `get_text_classifier()` needs to change.
"""
from dataclasses import dataclass
from typing import Optional, Protocol

from app.models import FodmapGroup, FodmapLabel


@dataclass
class GroupPrediction:
    label: FodmapLabel
    grams_per_portion: Optional[float]
    confidence: float


@dataclass
class TextFodmapPrediction:
    portion_size_g: float
    oligos: GroupPrediction
    fructose: GroupPrediction
    lactose: GroupPrediction
    polyols: GroupPrediction
    overall_confidence: float  # aggregate confidence used for the publish/reject decision
    model_version: str


class TextFodmapClassifier(Protocol):
    def predict(self, query: str, portion_size_g: Optional[float] = None) -> TextFodmapPrediction:
        ...


class HeuristicTextFodmapClassifier:
    """
    Placeholder implementation. Real version should:
      1. Look the query up against the seed dataset (existing 1000+
         product DB export mentioned in TZ 3.2) via fuzzy/embedding
         match first - highest-confidence path.
      2. Fall back to a trained text model (e.g. fine-tuned on the
         Monash DB + open composition tables) for unseen products.
      3. Never return confidence 1.0 outside of an exact seed-dataset
         hit; ML output should be capped (e.g. <= 0.95) to reflect that
         it's an estimate, matching the TZ's "estimation, not
         measurement" framing.
    """

    MODEL_VERSION = "heuristic-text-v0-placeholder"

    def predict(self, query: str, portion_size_g: Optional[float] = None) -> TextFodmapPrediction:
        portion = portion_size_g or 100.0
        normalized = query.strip().lower()

        # Extremely naive placeholder heuristic just so the endpoint is
        # exercisable; REPLACE with a real model call.
        garlic_onion_markers = ("garlic", "onion", "чеснок", "лук")
        dairy_markers = ("milk", "молоко", "cream", "сливки", "yogurt", "йогурт")
        fruit_markers = ("apple", "яблоко", "mango", "манго", "honey", "мёд", "мед")
        sugar_alcohol_markers = ("xylitol", "sorbitol", "ксилит", "сорбит", "mushroom", "гриб")

        def has_any(markers):
            return any(m in normalized for m in markers)

        oligos = GroupPrediction(
            label=FodmapLabel.high if has_any(garlic_onion_markers) else FodmapLabel.low,
            grams_per_portion=1.2 if has_any(garlic_onion_markers) else 0.05,
            confidence=0.55,
        )
        lactose = GroupPrediction(
            label=FodmapLabel.high if has_any(dairy_markers) else FodmapLabel.low,
            grams_per_portion=5.0 if has_any(dairy_markers) else 0.0,
            confidence=0.55,
        )
        fructose = GroupPrediction(
            label=FodmapLabel.moderate if has_any(fruit_markers) else FodmapLabel.low,
            grams_per_portion=0.5 if has_any(fruit_markers) else 0.05,
            confidence=0.5,
        )
        polyols = GroupPrediction(
            label=FodmapLabel.high if has_any(sugar_alcohol_markers) else FodmapLabel.low,
            grams_per_portion=1.0 if has_any(sugar_alcohol_markers) else 0.05,
            confidence=0.5,
        )

        overall_confidence = min(oligos.confidence, fructose.confidence, lactose.confidence, polyols.confidence)

        return TextFodmapPrediction(
            portion_size_g=portion,
            oligos=oligos,
            fructose=fructose,
            lactose=lactose,
            polyols=polyols,
            overall_confidence=overall_confidence,
            model_version=self.MODEL_VERSION,
        )


_classifier_singleton: Optional[TextFodmapClassifier] = None


def get_text_classifier() -> TextFodmapClassifier:
    """FastAPI-style dependency / factory. Centralising this makes it a
    one-line change to swap in the real model, and lets tests override it
    with a fake via dependency injection."""
    global _classifier_singleton
    if _classifier_singleton is None:
        _classifier_singleton = HeuristicTextFodmapClassifier()
    return _classifier_singleton
