"""
app/ml/meal_planner.py

Task 3 from the TZ: "Генерация персонального плана питания" - build a
meal plan from user preferences + current diet phase.

The TZ's diet-phase addendum is the key input this component must
respect:
  Phase 1 (elimination):      minimise ALL 4 FODMAP groups.
  Phase 2 (reintroduction):   one group at a time is deliberately
                               increased, one group per week, while the
                               rest stay minimised.
  Phase 3 (personalisation):  all groups reintroduced according to the
                               user's now-known individual tolerances.

As with the other two ML components, this is a stable interface
(`MealPlanner.generate`) with a rule-based placeholder implementation
(candidate-product filtering, not a trained model) so the planner
endpoint is runnable before a real recommender/generative model exists.
"""
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional, Protocol

from sqlalchemy.orm import Session

from app.models import DietPhase, FodmapGroup, FodmapLabel, Product


@dataclass
class PlannedMealSlot:
    day: str            # "monday" .. "sunday"
    meal_type: str       # breakfast / lunch / dinner / snack
    product_id: Optional[str]
    product_name: Optional[str]
    notes: str = ""


@dataclass
class GeneratedPlan:
    week_start: datetime
    phase: DietPhase
    slots: list = field(default_factory=list)  # list[PlannedMealSlot]

    def to_json_dict(self) -> dict:
        return {
            "week_start": self.week_start.isoformat(),
            "phase": self.phase.value,
            "slots": [
                {
                    "day": s.day,
                    "meal_type": s.meal_type,
                    "product_id": s.product_id,
                    "product_name": s.product_name,
                    "notes": s.notes,
                }
                for s in self.slots
            ],
        }


class MealPlanner(Protocol):
    def generate(
        self,
        db: Session,
        phase: DietPhase,
        current_reintro_group: Optional[FodmapGroup],
        preferences: Optional[dict],
        week_start: datetime,
    ) -> GeneratedPlan:
        ...


class RuleBasedMealPlanner:
    """
    Placeholder implementation: filters the product catalogue by
    FODMAP-label constraints appropriate to the current phase, then
    randomly assigns candidates to the week's meal slots. A real
    implementation would likely rank candidates with a learned model
    (collaborative filtering / LLM-based generation grounded in the
    catalogue) and factor in `preferences` (dislikes, allergies, cuisine,
    variety-over-time) much more richly.
    """

    _DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    _MEAL_TYPES = ["breakfast", "lunch", "dinner", "snack"]

    def generate(
        self,
        db: Session,
        phase: DietPhase,
        current_reintro_group: Optional[FodmapGroup],
        preferences: Optional[dict],
        week_start: datetime,
    ) -> GeneratedPlan:
        candidates = self._candidate_products(db, phase, current_reintro_group)

        plan = GeneratedPlan(week_start=week_start, phase=phase)
        for day in self._DAYS:
            for meal_type in self._MEAL_TYPES:
                if candidates:
                    product = random.choice(candidates)
                    plan.slots.append(PlannedMealSlot(
                        day=day,
                        meal_type=meal_type,
                        product_id=product.id,
                        product_name=product.name,
                    ))
                else:
                    plan.slots.append(PlannedMealSlot(
                        day=day,
                        meal_type=meal_type,
                        product_id=None,
                        product_name=None,
                        notes="No suitable low-FODMAP catalogue product found for this phase yet.",
                    ))
        return plan

    def _candidate_products(
        self, db: Session, phase: DietPhase, current_reintro_group: Optional[FodmapGroup]
    ) -> list[Product]:
        query = db.query(Product)

        if phase == DietPhase.elimination:
            # Strict: overall label must be low.
            query = query.filter(Product.overall_label == FodmapLabel.low)
            return query.limit(200).all()

        if phase == DietPhase.reintroduction:
            # All groups except the one being challenged must stay low;
            # the challenged group is allowed to be moderate/high so the
            # user can actually test their tolerance to it.
            base = query.filter(Product.overall_label != None)  # noqa: E711
            results = []
            for product in base.limit(500).all():
                group_labels = {
                    FodmapGroup.oligos: product.oligos_label,
                    FodmapGroup.fructose: product.fructose_label,
                    FodmapGroup.lactose: product.lactose_label,
                    FodmapGroup.polyols: product.polyols_label,
                }
                ok = True
                for group, label in group_labels.items():
                    if current_reintro_group is not None and group == current_reintro_group:
                        continue  # the challenged group may be elevated
                    if label != FodmapLabel.low:
                        ok = False
                        break
                if ok:
                    results.append(product)
            return results[:200]

        # phase 3 (personalisation): no blanket restriction here - a real
        # implementation should instead filter by the user's *individual*
        # per-group tolerance learned during phase 2, which isn't modelled
        # yet; for now we just avoid overall "high" products as a safe
        # default.
        return query.filter(Product.overall_label != FodmapLabel.high).limit(200).all()


_planner_singleton: Optional[MealPlanner] = None


def get_meal_planner() -> MealPlanner:
    global _planner_singleton
    if _planner_singleton is None:
        _planner_singleton = RuleBasedMealPlanner()
    return _planner_singleton
