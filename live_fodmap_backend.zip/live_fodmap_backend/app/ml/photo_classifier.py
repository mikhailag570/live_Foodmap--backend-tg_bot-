"""
app/ml/photo_classifier.py

Task 2 from the TZ: "Распознавание продукта по фото" - given a camera
photo, identify the product and its FODMAP profile, then add it to the
DB (subject to the same confidence gate as the text model).

Same pattern as text_classifier.py: this is a stable interface with a
placeholder implementation. A real implementation would typically be a
two-stage pipeline:
  1. Vision model -> product identity (e.g. "banana", packaged product
     barcode/label OCR) + its own confidence.
  2. FODMAP profile lookup/estimation for that identified product,
     reusing app.ml.text_classifier or a shared profile-lookup service
     for anything already in the seed dataset / Open Food Facts.
The two confidences should be combined (e.g. multiplied, or take the
min) into the single `overall_confidence` used for the publish/reject
decision in app.fodmap_logic.decide_publication.
"""
from dataclasses import dataclass
from typing import Optional, Protocol

from app.ml.text_classifier import TextFodmapPrediction, get_text_classifier


@dataclass
class PhotoRecognitionResult:
    predicted_label: str            # e.g. "banana", "greek_yogurt_500g"
    vision_confidence: float        # confidence of the "what is this" step
    fodmap_prediction: Optional[TextFodmapPrediction]  # None if recognition itself failed
    overall_confidence: float       # combined confidence used for publish/reject


class PhotoFodmapClassifier(Protocol):
    def predict(self, image_bytes: bytes, content_type: str) -> PhotoRecognitionResult:
        ...


class PlaceholderPhotoFodmapClassifier:
    """
    Placeholder implementation: does NOT actually run computer vision.
    It returns a fixed low-confidence "unknown product" result so the
    endpoint is exercisable end-to-end (upload -> storage -> pipeline ->
    confidence-gated response) before a real vision model is wired in.

    Replace with e.g. a call to an image classification model (self-hosted
    or a managed vision API), then feed the identified product name
    through the same FODMAP lookup used by the text classifier.
    """

    MODEL_VERSION = "placeholder-photo-v0"

    def predict(self, image_bytes: bytes, content_type: str) -> PhotoRecognitionResult:
        # A real model would inspect image_bytes here. We deliberately
        # return a low, "inconclusive-leaning" confidence so the
        # confidence-gating logic can be exercised realistically without
        # ever mis-labelling something as reliably-recognised.
        vision_confidence = 0.4
        recognised_label = "unrecognised_product"

        text_prediction = get_text_classifier().predict(recognised_label)
        overall_confidence = min(vision_confidence, text_prediction.overall_confidence)

        return PhotoRecognitionResult(
            predicted_label=recognised_label,
            vision_confidence=vision_confidence,
            fodmap_prediction=text_prediction,
            overall_confidence=overall_confidence,
        )


_classifier_singleton: Optional[PhotoFodmapClassifier] = None


def get_photo_classifier() -> PhotoFodmapClassifier:
    global _classifier_singleton
    if _classifier_singleton is None:
        _classifier_singleton = PlaceholderPhotoFodmapClassifier()
    return _classifier_singleton
