"""
app/storage.py

Photo storage. Implemented as local-disk storage under
settings.PHOTO_STORAGE_DIR, laid out as photos/{user_id}/{uuid}.{ext} so
files are namespaced per user. The interface (`save_photo`) is narrow on
purpose - swapping to S3/GCS later only means changing this one module.
"""
import os
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status

from app.config import settings

_EXT_BY_CONTENT_TYPE = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
}


def _validate_upload(upload: UploadFile, raw_bytes: bytes) -> None:
    if upload.content_type not in settings.ALLOWED_PHOTO_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported content type '{upload.content_type}'. "
                   f"Allowed: {', '.join(settings.ALLOWED_PHOTO_CONTENT_TYPES)}",
        )
    max_bytes = settings.MAX_PHOTO_SIZE_MB * 1024 * 1024
    if len(raw_bytes) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"Photo exceeds the {settings.MAX_PHOTO_SIZE_MB} MB limit",
        )


async def save_photo(upload: UploadFile, user_id: str) -> tuple[str, int]:
    """
    Validates and persists an uploaded photo.
    Returns (relative_file_path, size_bytes). Raises HTTPException on
    validation failure.
    """
    raw_bytes = await upload.read()
    _validate_upload(upload, raw_bytes)

    ext = _EXT_BY_CONTENT_TYPE[upload.content_type]
    relative_path = os.path.join(user_id, f"{uuid.uuid4()}.{ext}")
    absolute_path = Path(settings.PHOTO_STORAGE_DIR) / relative_path
    absolute_path.parent.mkdir(parents=True, exist_ok=True)

    with open(absolute_path, "wb") as f:
        f.write(raw_bytes)

    return relative_path, len(raw_bytes)


def read_photo_bytes(relative_path: str) -> bytes:
    absolute_path = Path(settings.PHOTO_STORAGE_DIR) / relative_path
    with open(absolute_path, "rb") as f:
        return f.read()


def delete_photo(relative_path: str) -> None:
    absolute_path = Path(settings.PHOTO_STORAGE_DIR) / relative_path
    if absolute_path.exists():
        absolute_path.unlink()
