"""
app/config.py

Centralised application settings, loaded from environment variables
(with sane local-dev defaults). Uses pydantic-settings so every other
module imports `settings` instead of reading os.environ directly.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- App ---
    APP_NAME: str = "Live FODMAP Backend"
    ENV: str = "dev"  # dev | staging | prod
    DEBUG: bool = True

    # --- Database ---
    # SQLite for now; the code is written against SQLAlchemy's engine
    # abstraction so swapping to Postgres later is a one-line change
    # (just change DATABASE_URL and drop the SQLite-only connect_args).
    DATABASE_URL: str = "sqlite:///./live_fodmap.db"

    # --- JWT auth ---
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_PROD_use_a_long_random_value"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # --- FODMAP business rules ---
    # Below this confidence, an ML-predicted product is NOT auto-published
    # to the shared catalogue; it stays in a "review" state and is only
    # visible to the user who triggered the prediction until a human
    # (or the user, via re-submission) confirms it.
    ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD: float = 0.70
    # Below this, we don't even show the prediction with confidence - we
    # tell the user it's inconclusive.
    ML_CONFIDENCE_MIN_USABLE_THRESHOLD: float = 0.35

    # Per-group thresholds (grams per portion) used for the traffic-light
    # classification. Source: TZ section 3.1 gives the "low" cut points
    # for Oligos (< 0.3 g) and Polyols (< 0.4 g) explicitly. Lactose and
    # Fructose thresholds and the moderate/high tiers for all four groups
    # are NOT specified in the TZ and are seeded here with commonly used
    # Monash-style approximations so the system is usable end-to-end;
    # THESE MUST BE REVIEWED/REPLACED with values signed off by a
    # nutrition specialist / the Monash licence data before going live.
    FODMAP_THRESHOLDS_G: dict = {
        "oligos":  {"low": 0.3, "moderate": 0.6},   # low: TZ-specified
        "fructose": {"low": 0.15, "moderate": 0.4}, # NOT in TZ - placeholder
        "lactose": {"low": 1.0, "moderate": 4.0},   # NOT in TZ - placeholder
        "polyols": {"low": 0.4, "moderate": 0.8},   # low: TZ-specified
    }

    # --- File storage (photos) ---
    PHOTO_STORAGE_DIR: str = "./storage/photos"
    MAX_PHOTO_SIZE_MB: int = 10
    ALLOWED_PHOTO_CONTENT_TYPES: tuple = ("image/jpeg", "image/png", "image/webp")

    # --- External data sources ---
    OPEN_FOOD_FACTS_BASE_URL: str = "https://world.openfoodfacts.org"
    OPEN_FOOD_FACTS_USER_AGENT: str = "LiveFODMAP/1.0 (contact@livefodmap.example)"
    USDA_FDC_BASE_URL: str = "https://api.nal.usda.gov/fdc/v1"
    USDA_FDC_API_KEY: str = "DEMO_KEY"  # replace with a real key in .env
    EXTERNAL_HTTP_TIMEOUT_SECONDS: float = 8.0


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
