"""
app/models.py

SQLAlchemy ORM models.

Domain notes (see TZ_FODMAP_ML_models.docx):
- A Product's FODMAP profile is split into 4 independent subgroups:
  Oligos, Fructose, Lactose, Polyols (section 3.1). Each subgroup gets
  its own traffic-light label (low/moderate/high) and, where available,
  a gram-per-portion estimate.
- Product.status distinguishes how the profile was obtained:
    predicted       -> produced by an ML model (text or photo), passed
                        the confidence threshold, auto-published.
    lab_verified     -> confirmed against a trusted source (Monash DB,
                        published composition tables, manual expert
                        review).
    user_submitted   -> a user manually entered/corrected the data, or
                        an ML prediction that DID NOT pass the
                        confidence threshold was submitted anyway.
- The Low-FODMAP diet used by the app has 3 phases (TZ section "Дополнение
  по 3 задаче"):
    1 = elimination  (minimise all 4 groups)
    2 = reintroduction (one group at a time, one group per week)
    3 = personalisation (all groups reintroduced, long-term diet)
  DietPhaseState tracks where a user currently is in that process.
"""
import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #

class FodmapLabel(str, enum.Enum):
    low = "low"
    moderate = "moderate"
    high = "high"


class ProductStatus(str, enum.Enum):
    predicted = "predicted"
    lab_verified = "lab_verified"
    user_submitted = "user_submitted"


class ProductSource(str, enum.Enum):
    text_ml_model = "text_ml_model"
    photo_ml_model = "photo_ml_model"
    manual_user_entry = "manual_user_entry"
    open_food_facts = "open_food_facts"
    usda_fdc = "usda_fdc"
    seed_dataset = "seed_dataset"


class DietPhase(int, enum.Enum):
    elimination = 1
    reintroduction = 2
    personalisation = 3


class FodmapGroup(str, enum.Enum):
    oligos = "oligos"
    fructose = "fructose"
    lactose = "lactose"
    polyols = "polyols"


class PhotoAnalysisStatus(str, enum.Enum):
    pending = "pending"
    processed = "processed"
    failed = "failed"


class MealType(str, enum.Enum):
    breakfast = "breakfast"
    lunch = "lunch"
    dinner = "dinner"
    snack = "snack"


# --------------------------------------------------------------------------- #
# User & auth
# --------------------------------------------------------------------------- #

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=_uuid)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False)

    diet_phase_state = relationship(
        "DietPhaseState", back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    meals = relationship("Meal", back_populates="user", cascade="all, delete-orphan")
    symptoms = relationship("Symptom", back_populates="user", cascade="all, delete-orphan")
    photos = relationship("Photo", back_populates="user", cascade="all, delete-orphan")
    plans = relationship("PlannerPlan", back_populates="user", cascade="all, delete-orphan")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")
    submitted_products = relationship("Product", back_populates="submitted_by")


class RefreshToken(Base):
    """
    Persisted refresh tokens so they can be revoked (logout / rotation)
    instead of relying purely on JWT expiry.
    """
    __tablename__ = "refresh_tokens"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_jti = Column(String(36), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    revoked = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    user = relationship("User", back_populates="refresh_tokens")


# --------------------------------------------------------------------------- #
# Product & FODMAP profile
# --------------------------------------------------------------------------- #

class Product(Base):
    """
    A food product with its FODMAP profile.

    The 4 FODMAP subgroups are stored as separate columns (rather than a
    generic key/value table) because the TZ requires distinct low /
    moderate / high labels and gram estimates for each, and this keeps
    joins/queries simple. A generic `FodmapMeasurement` child table is
    still provided (see below) to hold the raw, versioned lab/ML
    measurements that these summary columns are derived from.
    """
    __tablename__ = "products"

    id = Column(String(36), primary_key=True, default=_uuid)
    name = Column(String(255), nullable=False, index=True)
    barcode = Column(String(64), nullable=True, unique=True, index=True)
    brand = Column(String(255), nullable=True)

    portion_size_g = Column(Float, nullable=False)

    # Per-group grams-per-portion (nullable: a model may only be able to
    # give a label, not a quantitative estimate) + traffic-light label.
    oligos_g = Column(Float, nullable=True)
    oligos_label = Column(Enum(FodmapLabel), nullable=False)
    fructose_g = Column(Float, nullable=True)
    fructose_label = Column(Enum(FodmapLabel), nullable=False)
    lactose_g = Column(Float, nullable=True)
    lactose_label = Column(Enum(FodmapLabel), nullable=False)
    polyols_g = Column(Float, nullable=True)
    polyols_label = Column(Enum(FodmapLabel), nullable=False)

    # Overall label = worst (highest) of the 4 subgroup labels, computed
    # by app.fodmap_logic.compute_overall_label() and stored for fast
    # querying/filtering.
    overall_label = Column(Enum(FodmapLabel), nullable=False)

    confidence = Column(Float, nullable=False)  # 0..1
    status = Column(Enum(ProductStatus), nullable=False, default=ProductStatus.predicted)
    source = Column(Enum(ProductSource), nullable=False)

    ingredients_text = Column(Text, nullable=True)  # raw ingredient list, e.g. from OFF
    submitted_by_id = Column(String(36), ForeignKey("users.id"), nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False)

    submitted_by = relationship("User", back_populates="submitted_products")
    measurements = relationship("FodmapMeasurement", back_populates="product", cascade="all, delete-orphan")
    meals = relationship("Meal", back_populates="product")
    photos = relationship("Photo", back_populates="product")


class FodmapMeasurement(Base):
    """
    Append-only audit trail: every time a value for this product is
    (re)computed - by the text model, the photo model, an OFF/USDA sync,
    or a human correction - we keep the raw record here. `Product`'s
    summary columns always reflect the *latest accepted* measurement,
    but nothing is overwritten/lost.
    """
    __tablename__ = "fodmap_measurements"

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)

    group = Column(Enum(FodmapGroup), nullable=False)
    grams_per_portion = Column(Float, nullable=True)
    label = Column(Enum(FodmapLabel), nullable=False)
    confidence = Column(Float, nullable=False)
    source = Column(Enum(ProductSource), nullable=False)
    model_version = Column(String(64), nullable=True)  # e.g. "text-fodmap-v0.3.1"

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    product = relationship("Product", back_populates="measurements")


# --------------------------------------------------------------------------- #
# Photo capture / recognition pipeline
# --------------------------------------------------------------------------- #

class Photo(Base):
    __tablename__ = "photos"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    file_path = Column(String(512), nullable=False)  # relative path under PHOTO_STORAGE_DIR
    content_type = Column(String(64), nullable=False)
    size_bytes = Column(Integer, nullable=False)

    status = Column(Enum(PhotoAnalysisStatus), nullable=False, default=PhotoAnalysisStatus.pending)
    predicted_label = Column(String(255), nullable=True)  # raw class name from the vision model
    predicted_confidence = Column(Float, nullable=True)

    product_id = Column(String(36), ForeignKey("products.id"), nullable=True)  # linked once resolved
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    processed_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="photos")
    product = relationship("Product", back_populates="photos")


# --------------------------------------------------------------------------- #
# Meals & symptoms (tracking)
# --------------------------------------------------------------------------- #

class Meal(Base):
    __tablename__ = "meals"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(String(36), ForeignKey("products.id"), nullable=True)
    recipe_id = Column(String(36), ForeignKey("recipes.id"), nullable=True)

    meal_type = Column(Enum(MealType), nullable=False)
    quantity_g = Column(Float, nullable=False)
    eaten_at = Column(DateTime(timezone=True), nullable=False, default=_utcnow)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    user = relationship("User", back_populates="meals")
    product = relationship("Product", back_populates="meals")
    recipe = relationship("Recipe", back_populates="meals")


class Symptom(Base):
    __tablename__ = "symptoms"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    symptom_type = Column(String(100), nullable=False)  # e.g. "bloating", "pain", "diarrhea"
    severity = Column(Integer, nullable=False)  # 1..10
    recorded_at = Column(DateTime(timezone=True), nullable=False, default=_utcnow)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    user = relationship("User", back_populates="symptoms")


# --------------------------------------------------------------------------- #
# Recipes
# --------------------------------------------------------------------------- #

class Recipe(Base):
    __tablename__ = "recipes"

    id = Column(String(36), primary_key=True, default=_uuid)
    name = Column(String(255), nullable=False, index=True)
    instructions = Column(Text, nullable=False)
    portion_size_g = Column(Float, nullable=False)
    overall_label = Column(Enum(FodmapLabel), nullable=False)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    ingredients = relationship("RecipeIngredient", back_populates="recipe", cascade="all, delete-orphan")
    meals = relationship("Meal", back_populates="recipe")


class RecipeIngredient(Base):
    __tablename__ = "recipe_ingredients"
    __table_args__ = (UniqueConstraint("recipe_id", "product_id", name="uq_recipe_product"),)

    id = Column(String(36), primary_key=True, default=_uuid)
    recipe_id = Column(String(36), ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(String(36), ForeignKey("products.id"), nullable=False)
    quantity_g = Column(Float, nullable=False)

    recipe = relationship("Recipe", back_populates="ingredients")
    product = relationship("Product")


# --------------------------------------------------------------------------- #
# Diet phase tracking (TZ: 3 phases of the Low-FODMAP protocol)
# --------------------------------------------------------------------------- #

class DietPhaseState(Base):
    """
    One row per user tracking where they are in the elimination ->
    reintroduction -> personalisation protocol, and (for phase 2) which
    FODMAP group is currently being challenged.
    """
    __tablename__ = "diet_phase_states"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)

    phase = Column(Enum(DietPhase), nullable=False, default=DietPhase.elimination)
    phase_started_at = Column(DateTime(timezone=True), nullable=False, default=_utcnow)

    # Only meaningful during phase 2 (reintroduction): which group is
    # being challenged this week, and which groups are already done.
    current_reintro_group = Column(Enum(FodmapGroup), nullable=True)
    completed_reintro_groups = Column(String(255), nullable=True)  # comma-separated FodmapGroup values

    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False)

    user = relationship("User", back_populates="diet_phase_state")


# --------------------------------------------------------------------------- #
# Meal planner output
# --------------------------------------------------------------------------- #

class PlannerPlan(Base):
    """
    A generated meal plan. `plan_json` stores the structured output from
    the planner ML component (see app/ml/meal_planner.py) so the API can
    return it without re-deriving anything; `phase` records which diet
    phase it was generated for (plans differ a lot between phase 1 and
    phase 2/3).
    """
    __tablename__ = "planner_plans"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    phase = Column(Enum(DietPhase), nullable=False)
    week_start = Column(DateTime(timezone=True), nullable=False)
    plan_json = Column(Text, nullable=False)  # JSON-encoded structured plan

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    user = relationship("User", back_populates="plans")
