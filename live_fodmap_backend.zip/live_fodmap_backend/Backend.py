"""
Backend.py (project entrypoint, kept at repo root to match the original
skeleton's filename/import path)

Wires together config, DB, and all routers. For local dev, tables are
created via Alembic migrations (see alembic/ and README.md) - this file
does NOT call Base.metadata.create_all(), so "run the app" and "manage
schema" stay properly separated (create_all is fine for a quick throwaway
demo but does not track schema changes the way Alembic does).
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import auth, diet_phase, meals, photo, planner, products, symptoms

app = FastAPI(title=settings.APP_NAME, debug=settings.DEBUG)

# CORS: permissive for local/dev; tighten allow_origins for production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.ENV == "dev" else [],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(products.router)
app.include_router(photo.router)
app.include_router(meals.router)
app.include_router(symptoms.router)
app.include_router(planner.router)
app.include_router(diet_phase.router)


@app.get("/")
def root():
    return {"message": "Live FODMAP Backend is running", "env": settings.ENV}
