# Live FODMAP Backend

Реализация бэкенда согласно `TZ_FODMAP_ML_models.docx`: SQLite + Alembic-миграции,
полноценная JWT-авторизация (access + refresh, ротация, отзыв), три интеграционные
точки для ML-компонентов (текст → FODMAP-профиль, фото → продукт, генератор плана
питания), загрузка/хранение фотографий, интеграция с Open Food Facts и USDA
FoodData Central, и бизнес-логика статусов продукта (`predicted` / `lab_verified`
/ `user_submitted`) на основе confidence-порогов.

## Быстрый старт

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # и отредактировать под себя

# применить миграции (создаёт live_fodmap.db со всеми таблицами)
alembic upgrade head

# запустить сервер
uvicorn Backend:app --reload
```

Swagger UI: http://localhost:8000/docs

## Структура проекта

```
.
├── Backend.py                 # точка входа FastAPI (сохранил исходное имя файла)
├── alembic.ini
├── alembic/
│   ├── env.py                  # подключён к app.database.Base и app.config.settings
│   ├── script.py.mako
│   └── versions/
│       └── 0001_initial.py     # создаёт все таблицы (см. примечание ниже)
├── app/
│   ├── config.py                # настройки: DB URL, JWT, пороги confidence, пороги FODMAP-групп
│   ├── database.py               # SQLAlchemy engine/session (SQLite, PRAGMA foreign_keys=ON)
│   ├── models.py                  # ORM-модели (см. ниже)
│   ├── schemas.py                 # Pydantic-схемы запросов/ответов
│   ├── auth.py                    # хэширование паролей + JWT (access/refresh, ротация, отзыв)
│   ├── fodmap_logic.py             # traffic-light классификация, overall_label, confidence-гейтинг
│   ├── storage.py                  # сохранение/чтение загруженных фото на диске
│   ├── ml/
│   │   ├── text_classifier.py       # Задача 1 ТЗ: текст → FODMAP-профиль (заглушка + стабильный интерфейс)
│   │   ├── photo_classifier.py      # Задача 2 ТЗ: фото → продукт → FODMAP-профиль
│   │   └── meal_planner.py          # Задача 3 ТЗ: генерация плана питания по фазам диеты
│   ├── external/
│   │   ├── openfoodfacts.py         # клиент Open Food Facts (штрихкод, поиск по названию)
│   │   └── usda.py                  # клиент USDA FoodData Central (нутриентные фичи)
│   └── routers/
│       ├── auth.py                  # /auth/register /login /refresh /logout /me
│       ├── products.py               # /products/{name}, POST /products, /products/predict-text, /verify
│       ├── photo.py                  # /photo/analyze
│       ├── meals.py                  # /meals
│       ├── symptoms.py               # /symptoms
│       ├── planner.py                 # /planner/generate, /planner
│       └── diet_phase.py              # /diet-phase, /diet-phase/advance
├── storage/photos/              # загруженные фото (per-user поддиректории)
├── requirements.txt
└── .env.example
```

## Модель данных (ключевые таблицы)

- **users / refresh_tokens** — учётки и отзываемые refresh-токены.
- **products** — карточка продукта с раздельным профилем по 4 группам FODMAP
  (Oligos / Fructose / Lactose / Polyols): грамм/порция + traffic-light метка
  (`low`/`moderate`/`high`) на каждую группу, `overall_label` (худшая из четырёх),
  `confidence`, `status` (`predicted`/`lab_verified`/`user_submitted`), `source`.
- **fodmap_measurements** — неизменяемый журнал всех измерений/предсказаний по
  продукту (для аудита: кто/что/когда посчитал профиль).
- **photos** — загруженные фото, статус обработки, распознанный продукт.
- **meals / symptoms** — трекинг приёмов пищи и симптомов.
- **recipes / recipe_ingredients** — база рецептов.
- **diet_phase_states** — текущая фаза Low-FODMAP протокола пользователя
  (1 — элиминация, 2 — реинтродукция по одной группе в неделю, 3 —
  персонализация) и прогресс по реинтродукции.
- **planner_plans** — сгенерированные планы питания (JSON), привязанные к фазе.

## Бизнес-логика confidence/status (`app/fodmap_logic.py`)

Согласно ТЗ («модели — это системы оценки с уверенностью, а не измерения»):

| confidence | Итог |
|---|---|
| ≥ `ML_CONFIDENCE_AUTO_PUBLISH_THRESHOLD` (0.70 по умолчанию) | автопубликация, `status=predicted`, продукт сразу виден всем |
| между `MIN_USABLE` (0.35) и `AUTO_PUBLISH` | сохраняется как `status=user_submitted` (нужно подтверждение) |
| < `MIN_USABLE` | ничего не сохраняется, пользователю предлагается повторить/ввести вручную |

`status=lab_verified` выставляется **только** явным вызовом `/products/{id}/verify`
(только superuser) — никогда автоматически.

**Важно:** пороги для классификации групп (`FODMAP_THRESHOLDS_G` в `config.py`)
для Oligos (< 0.3 г) и Polyols (< 0.4 г) взяты прямо из ТЗ. Пороги для Lactose,
Fructose и верхние границы `moderate`/`high` **не заданы в ТЗ** и сейчас — это
placeholder-приближения; их нужно согласовать с нутрициологом/данными Monash
перед продакшеном (помечено комментариями в коде).

## ML-компоненты

Каждый модуль в `app/ml/` — это **стабильный интерфейс + placeholder-реализация**:
- `text_classifier.py` — сейчас работает на простых keyword-эвристиках, чтобы
  эндпоинт `/products/predict-text` был рабочим сквозь весь пайплайн уже сейчас.
- `photo_classifier.py` — placeholder специально возвращает низкий confidence
  (никакого реального CV пока нет), чтобы не выдавать ложную уверенность.
- `meal_planner.py` — правило-based фильтрация каталога по фазе диеты.

Замена на настоящие обученные модели = переписать реализацию внутри модуля,
роутеры и остальной код трогать не нужно (фабрики `get_text_classifier()`,
`get_photo_classifier()`, `get_meal_planner()` — единственная точка подключения).

## Открытые вопросы / TODO перед продакшеном

1. Реальные ML-модели вместо заглушек (текст, фото, планировщик).
2. Согласовать полную таблицу порогов FODMAP-групп (сейчас частично placeholder).
3. Лицензирование Monash FODMAP database (ТЗ отмечает её как проприетарную).
4. `alembic/versions/0001_initial.py` написан вручную (в песочнице нет доступа
   к сети для `pip install`/`alembic revision --autogenerate`) — перед
   применением в реальном окружении рекомендуется прогнать
   `alembic revision --autogenerate` на пустой БД и сверить diff с этим файлом.
5. Продакшен-хранилище фото (сейчас — локальный диск; вынести в S3/GCS через
   `app/storage.py`).
6. Ограничить CORS `allow_origins` для non-dev окружений (`app/config.py` /
   `Backend.py`).
