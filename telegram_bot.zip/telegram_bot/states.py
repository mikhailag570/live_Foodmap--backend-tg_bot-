"""
states.py

aiogram 3 FSM state groups for every multi-step conversation in the bot.
"""
from aiogram.fsm.state import State, StatesGroup


class Registration(StatesGroup):
    age = State()
    gender = State()
    weight = State()
    height = State()
    diagnosis = State()
    allergies_yes_no = State()
    allergies_detail = State()
    preferences = State()
    restrictions = State()
    diet_phase_choice = State()
    diet_phase_start_group = State()  # only visited if phase 2 was chosen


class ProductTextSearch(StatesGroup):
    waiting_query = State()


class DiaryAddMeal(StatesGroup):
    waiting_product_query = State()
    choosing_meal_type = State()
    waiting_quantity = State()


class SymptomAdd(StatesGroup):
    choosing_type = State()
    choosing_severity = State()
    waiting_notes = State()


class DietPhaseAdvance(StatesGroup):
    choosing_next_group = State()


class PlannerPreferences(StatesGroup):
    waiting_free_text = State()
