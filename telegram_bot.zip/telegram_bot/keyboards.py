"""
keyboards.py

All ReplyKeyboardMarkup / InlineKeyboardMarkup builders, kept in one
place so handlers just import and call these instead of constructing
markup inline.
"""
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

# --------------------------------------------------------------------------- #
# Main menu (persistent reply keyboard, per the pipeline doc's "Главное меню")
# --------------------------------------------------------------------------- #

BTN_FIND_PRODUCT = "🔍 Определить продукт"
BTN_PHOTO = "📷 Распознать по фото"
BTN_DIARY = "📔 Мой дневник"
BTN_PLANNER = "📅 План питания"
BTN_SYMPTOMS = "🩺 Мои симптомы"
BTN_SETTINGS = "⚙️ Настройки"


def main_menu_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_FIND_PRODUCT), KeyboardButton(text=BTN_PHOTO)],
            [KeyboardButton(text=BTN_DIARY), KeyboardButton(text=BTN_PLANNER)],
            [KeyboardButton(text=BTN_SYMPTOMS), KeyboardButton(text=BTN_SETTINGS)],
        ],
        resize_keyboard=True,
    )


def remove_kb() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()


# --------------------------------------------------------------------------- #
# Registration
# --------------------------------------------------------------------------- #

def gender_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Мужской", callback_data="gender:male"),
            InlineKeyboardButton(text="Женский", callback_data="gender:female"),
            InlineKeyboardButton(text="Другое", callback_data="gender:other"),
        ]
    ])


def yes_no_kb(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Да", callback_data=f"{prefix}:yes"),
            InlineKeyboardButton(text="Нет", callback_data=f"{prefix}:no"),
        ]
    ])


def diet_phase_choice_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="1. Элиминация", callback_data="phase:elimination")],
        [InlineKeyboardButton(text="2. Реинтродукция", callback_data="phase:reintroduction")],
        [InlineKeyboardButton(text="3. Поддержание", callback_data="phase:personalisation")],
    ])


_GROUP_LABELS = {
    "oligos": "Олигосахариды",
    "fructose": "Фруктоза",
    "lactose": "Лактоза",
    "polyols": "Полиолы",
}


def fodmap_group_kb(exclude: frozenset = frozenset()) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=label, callback_data=f"group:{key}")]
        for key, label in _GROUP_LABELS.items()
        if key not in exclude
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# --------------------------------------------------------------------------- #
# Diary
# --------------------------------------------------------------------------- #

def diary_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить приём пищи", callback_data="diary:add")],
        [InlineKeyboardButton(text="📖 История", callback_data="diary:history")],
    ])


def meal_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Завтрак", callback_data="meal_type:breakfast"),
            InlineKeyboardButton(text="Обед", callback_data="meal_type:lunch"),
        ],
        [
            InlineKeyboardButton(text="Ужин", callback_data="meal_type:dinner"),
            InlineKeyboardButton(text="Перекус", callback_data="meal_type:snack"),
        ],
    ])


# --------------------------------------------------------------------------- #
# Symptoms
# --------------------------------------------------------------------------- #

_SYMPTOM_TYPES = ["вздутие", "боль", "газообразование", "тошнота", "диарея", "запор"]


def symptom_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Отметить симптом", callback_data="symptom:add")],
        [InlineKeyboardButton(text="📖 История", callback_data="symptom:history")],
    ])


def symptom_type_kb() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=t.capitalize(), callback_data=f"symptom_type:{t}")]
            for t in _SYMPTOM_TYPES]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def severity_kb() -> InlineKeyboardMarkup:
    row1 = [InlineKeyboardButton(text=str(i), callback_data=f"severity:{i}") for i in range(1, 6)]
    row2 = [InlineKeyboardButton(text=str(i), callback_data=f"severity:{i}") for i in range(6, 11)]
    return InlineKeyboardMarkup(inline_keyboard=[row1, row2])


# --------------------------------------------------------------------------- #
# Planner
# --------------------------------------------------------------------------- #

def planner_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✨ Сгенерировать план", callback_data="planner:generate")],
        [InlineKeyboardButton(text="📖 Мои планы", callback_data="planner:history")],
    ])


# --------------------------------------------------------------------------- #
# Settings
# --------------------------------------------------------------------------- #

def settings_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👤 Мой профиль", callback_data="settings:profile")],
        [InlineKeyboardButton(text="🥗 Этап диеты", callback_data="settings:diet_phase")],
        [InlineKeyboardButton(text="🚪 Выйти (забыть меня)", callback_data="settings:logout")],
    ])


def confirm_logout_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Да, удалить мои данные", callback_data="logout:confirm"),
            InlineKeyboardButton(text="Отмена", callback_data="logout:cancel"),
        ]
    ])


def skip_kb(callback_data: str = "skip") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Пропустить", callback_data=callback_data)]])
