"""
config.py

Bot-side settings. Deliberately separate from the backend's app/config.py
(this process is a different deployable unit - see README.md "Размещение").
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class BotSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Telegram ---
    # Obtained from @BotFather. NOT set/created by this codebase - you supply
    # your own real token at deploy time (see README "Как получить токен").
    BOT_TOKEN: str = "0000000000:TEST_TOKEN_PLACEHOLDER_REPLACE_ME"

    # --- Backend (the FastAPI project from live_fodmap_backend/) ---
    BACKEND_BASE_URL: str = "http://localhost:8000"
    BACKEND_HTTP_TIMEOUT_SECONDS: float = 15.0

    # --- Local bot-side storage ---
    # Maps telegram_id -> backend JWT tokens + the extended health profile
    # fields (age, weight, diagnosis, ...) that the current backend's User
    # model does not yet store (see README "Известные ограничения").
    LOCAL_DB_PATH: str = "./telegram_bot_local.db"

    # --- Symptom reminder (TZ: "через несколько часов бот напоминает") ---
    SYMPTOM_REMINDER_DELAY_MINUTES: int = 180

    # --- Photo handling ---
    MAX_PHOTO_DOWNLOAD_MB: int = 10


@lru_cache
def get_bot_settings() -> BotSettings:
    return BotSettings()


settings = get_bot_settings()
