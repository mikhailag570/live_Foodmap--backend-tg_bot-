"""
bot.py

Entrypoint. Run with:  python bot.py
(see README.md "Размещение" for how this process relates to the FastAPI
backend - they are two separate deployables that only talk over HTTP.)

Uses long-polling (getUpdates) for simplicity; see README for the
webhook alternative in production behind HTTPS.
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

import local_storage
from config import settings
from handlers import diary, planner, product_photo, product_text, settings as settings_handlers, start, symptoms
from middlewares.auth import BackendAuthMiddleware

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger(__name__)


async def main() -> None:
    local_storage.init_db()

    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    auth_middleware = BackendAuthMiddleware()
    dp.message.middleware(auth_middleware)
    dp.callback_query.middleware(auth_middleware)

    dp.include_router(start.router)
    dp.include_router(product_text.router)
    dp.include_router(product_photo.router)
    dp.include_router(diary.router)
    dp.include_router(symptoms.router)
    dp.include_router(planner.router)
    dp.include_router(settings_handlers.router)

    logger.info("Starting bot against backend %s", settings.BACKEND_BASE_URL)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
