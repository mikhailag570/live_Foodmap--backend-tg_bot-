"""
tests/test_local_storage.py

Exercises local_storage.py against a real temporary SQLite file (stdlib
sqlite3 only). No aiogram/httpx/bot token required.
"""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import local_storage as ls


def _tmp_db():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.remove(path)  # let sqlite create it fresh
    ls.init_db(path)
    return path


def test_create_and_get_user_roundtrip():
    db = _tmp_db()
    try:
        assert ls.get_user(1, db) is None
        ls.create_user(1, "uuid-1", "tg_1@bot.local", "pw", "acc1", "ref1", "2026-07-08T12:00:00Z", db)
        user = ls.get_user(1, db)
        assert user.backend_user_id == "uuid-1"
        assert user.access_token == "acc1"
    finally:
        os.remove(db)


def test_update_tokens():
    db = _tmp_db()
    try:
        ls.create_user(2, "uuid-2", "tg_2@bot.local", "pw", "acc1", "ref1", "t1", db)
        ls.update_tokens(2, "acc2", "ref2", "t2", db)
        user = ls.get_user(2, db)
        assert user.access_token == "acc2"
        assert user.refresh_token == "ref2"
    finally:
        os.remove(db)


def test_create_user_upsert_on_conflict():
    db = _tmp_db()
    try:
        ls.create_user(3, "uuid-3", "tg_3@bot.local", "pw", "acc1", "ref1", "t1", db)
        ls.create_user(3, "uuid-3", "tg_3@bot.local", "pw", "acc-new", "ref-new", "t2", db)
        user = ls.get_user(3, db)
        assert user.access_token == "acc-new"
    finally:
        os.remove(db)


def test_profile_roundtrip():
    db = _tmp_db()
    try:
        profile = ls.ProfileRecord(
            telegram_id=4, age=29, gender="female", weight_kg=61.5, height_cm=167.0,
            diagnosis="IBS-D", has_allergies=True, allergies_detail="орехи",
            preferences="вегетарианка", restrictions="без глютена",
        )
        ls.save_profile(profile, db)
        loaded = ls.get_profile(4, db)
        assert loaded.age == 29
        assert loaded.has_allergies is True
        assert loaded.allergies_detail == "орехи"
    finally:
        os.remove(db)


def test_delete_user_removes_profile_too():
    db = _tmp_db()
    try:
        ls.create_user(5, "uuid-5", "tg_5@bot.local", "pw", "acc1", "ref1", "t1", db)
        ls.save_profile(ls.ProfileRecord(5, 30, "male", 80.0, 180.0, None, False, None, None, None), db)
        ls.delete_user(5, db)
        assert ls.get_user(5, db) is None
        assert ls.get_profile(5, db) is None
    finally:
        os.remove(db)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"OK: {t.__name__}")
    print(f"{len(tests)} tests passed")
