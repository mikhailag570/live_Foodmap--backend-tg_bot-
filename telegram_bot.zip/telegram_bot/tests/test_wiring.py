"""
tests/test_wiring.py

Structural integration checks that catch "forgot to wire it up" bugs
(missing router include, renamed handler, missing api_client function)
WITHOUT needing aiogram/httpx installed or a real bot token - it parses
the source with the stdlib `ast` module instead of importing it.

This is what stands in, in this sandbox, for "start the bot and see if
it responds" - see README.md "Тестирование без токена бота" for the
full explanation of what was/wasn't executed live and why.
"""
import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _parse(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def _defined_function_names(tree: ast.Module) -> set:
    return {
        node.name for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def _string_literals(tree: ast.Module) -> set:
    return {node.value for node in ast.walk(tree) if isinstance(node, ast.Constant) and isinstance(node.value, str)}


def test_bot_py_includes_every_handler_router():
    bot_source = (ROOT / "bot.py").read_text(encoding="utf-8")
    expected_router_includes = [
        "start.router", "product_text.router", "product_photo.router",
        "diary.router", "symptoms.router", "planner.router", "settings_handlers.router",
    ]
    for expected in expected_router_includes:
        assert expected in bot_source, f"bot.py is missing dp.include_router({expected})"


def test_bot_py_registers_auth_middleware_for_messages_and_callbacks():
    bot_source = (ROOT / "bot.py").read_text(encoding="utf-8")
    assert "dp.message.middleware(auth_middleware)" in bot_source
    assert "dp.callback_query.middleware(auth_middleware)" in bot_source


def test_every_handler_module_defines_a_router_named_router():
    handlers_dir = ROOT / "handlers"
    for path in handlers_dir.glob("*.py"):
        if path.name == "__init__.py":
            continue
        tree = _parse(path)
        assigned_names = {
            target.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Assign)
            for target in node.targets
            if isinstance(target, ast.Name)
        }
        assert "router" in assigned_names, f"{path.name} does not define a module-level `router`"


def test_api_client_defines_all_functions_used_by_handlers():
    api_client_tree = _parse(ROOT / "api_client.py")
    defined = _defined_function_names(api_client_tree)

    required = {
        "register", "login", "refresh", "logout", "me",
        "get_product_by_name", "predict_text", "submit_product_manual",
        "analyze_photo",
        "add_meal", "list_meals",
        "add_symptom", "list_symptoms",
        "get_diet_phase", "advance_diet_phase",
        "generate_plan", "list_plans",
    }
    missing = required - defined
    assert not missing, f"api_client.py is missing expected functions: {missing}"

    # Cross-check: every api_client.<name> call site in handlers/ must
    # correspond to a function that actually exists above.
    handlers_dir = ROOT / "handlers"
    for path in handlers_dir.glob("*.py"):
        tree = _parse(path)
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Name)
                and node.value.id == "api_client"
            ):
                assert node.attr in defined, (
                    f"{path.name} calls api_client.{node.attr}, which is not defined in api_client.py"
                )


def test_states_used_by_handlers_are_all_defined():
    states_tree = _parse(ROOT / "states.py")
    defined_classes = {
        node.name for node in ast.walk(states_tree) if isinstance(node, ast.ClassDef)
    }
    expected = {
        "Registration", "ProductTextSearch", "DiaryAddMeal", "SymptomAdd",
        "DietPhaseAdvance", "PlannerPreferences",
    }
    assert expected.issubset(defined_classes)


def test_config_defines_settings_used_across_the_codebase():
    config_tree = _parse(ROOT / "config.py")
    source = (ROOT / "config.py").read_text(encoding="utf-8")
    for field in ["BOT_TOKEN", "BACKEND_BASE_URL", "LOCAL_DB_PATH", "SYMPTOM_REMINDER_DELAY_MINUTES"]:
        assert field in source, f"config.py is missing the {field} setting"


def test_keyboards_module_exposes_every_button_label_used_by_handlers():
    kb_tree = _parse(ROOT / "keyboards.py")
    defined = {
        node.targets[0].id
        for node in ast.walk(kb_tree)
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
    }
    for expected in ["BTN_FIND_PRODUCT", "BTN_PHOTO", "BTN_DIARY", "BTN_PLANNER", "BTN_SYMPTOMS", "BTN_SETTINGS"]:
        assert expected in defined, f"keyboards.py is missing button constant {expected}"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"OK: {t.__name__}")
    print(f"{len(tests)} tests passed")
