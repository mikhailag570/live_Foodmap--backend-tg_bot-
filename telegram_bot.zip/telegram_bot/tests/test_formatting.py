"""
tests/test_formatting.py

Pure-stdlib tests for utils/formatting.py. Runnable directly with
`python3 tests/test_formatting.py`, no third-party deps required.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from utils.formatting import (
    format_diet_phase,
    format_fodmap_profile,
    format_publish_notice,
    label_emoji,
    severity_bar,
)

SAMPLE_PRODUCT = {
    "name": "Молоко 3.2%",
    "portion_size_g": 100.0,
    "oligos_label": "low", "oligos_g": 0.05,
    "fructose_label": "low", "fructose_g": 0.0,
    "lactose_label": "high", "lactose_g": 5.0,
    "polyols_label": "low", "polyols_g": 0.0,
    "overall_label": "high",
    "confidence": 0.82,
    "status": "predicted",
}


def test_profile_contains_name_and_confidence():
    out = format_fodmap_profile(SAMPLE_PRODUCT)
    assert "Молоко 3.2%" in out
    assert "82%" in out
    assert "Лактоза" in out


def test_label_emoji_mapping():
    assert label_emoji("low") == "🟢"
    assert label_emoji("moderate") == "🟡"
    assert label_emoji("high") == "🔴"
    assert label_emoji("unknown") == "⚪"


def test_severity_bar_counts():
    bar = severity_bar(7)
    assert bar.count("🟥") == 7
    assert bar.count("⬜") == 3
    assert "7/10" in bar


def test_severity_bar_clamps_out_of_range():
    assert severity_bar(0).count("🟥") == 1
    assert severity_bar(99).count("🟥") == 10


def test_publish_notice_wording_differs_by_status():
    published = format_publish_notice(True, "ok")
    unpublished = format_publish_notice(False, "needs review")
    assert "добавлен" in published
    assert "требует проверки" in unpublished


def test_diet_phase_formatting_includes_group_progress():
    phase_state = {
        "phase": "reintroduction",
        "phase_started_at": "2026-07-01T00:00:00Z",
        "current_reintro_group": "lactose",
        "completed_reintro_groups": "oligos",
    }
    out = format_diet_phase(phase_state)
    assert "Реинтродукция" in out
    assert "Лактоза" in out
    assert "Олигосахариды" in out


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"OK: {t.__name__}")
    print(f"{len(tests)} tests passed")
