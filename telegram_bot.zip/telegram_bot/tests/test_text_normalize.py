"""
tests/test_text_normalize.py

Pure-stdlib tests - runnable with plain `python3 tests/test_text_normalize.py`
or with pytest if installed. No aiogram/httpx/bot token required.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from utils.text_normalize import is_query_too_long, is_query_too_short, normalize_product_query


def test_lowercases_and_trims():
    assert normalize_product_query("  ЯБЛОКО  ") == "яблоко"


def test_collapses_whitespace_and_strips_punctuation():
    assert normalize_product_query("green   apple!") == "green apple"


def test_handles_mixed_script_and_case():
    assert normalize_product_query("Apple") == "apple"
    assert normalize_product_query("Красная фасоль") == "красная фасоль"


def test_none_input_returns_empty_string():
    assert normalize_product_query(None) == ""


def test_length_guards():
    assert is_query_too_short("a") is True
    assert is_query_too_short("ab") is False
    assert is_query_too_long("x" * 201) is True
    assert is_query_too_long("x" * 200) is False


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"OK: {t.__name__}")
    print(f"{len(tests)} tests passed")
