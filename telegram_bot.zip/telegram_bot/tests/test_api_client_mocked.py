"""
tests/test_api_client_mocked.py

Verifies api_client.py's request-building and response-parsing logic
against a MOCKED backend (via respx intercepting httpx) - no real
network call, no real backend process, no bot token needed.

NOTE: unlike the other three test files in this folder, this one
requires third-party packages (aiogram's dependency httpx, plus respx
and pytest-asyncio) that could NOT be installed in the sandbox used to
build this project (no network egress there - see README.md
"Тестирование без токена бота"). It is included for completeness and
should pass once you run:

    pip install -r requirements.txt pytest pytest-asyncio respx
    pytest tests/test_api_client_mocked.py

but has NOT itself been executed as part of this delivery.
"""
import sys
from pathlib import Path

import pytest
import respx
from httpx import Response

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from config import settings


@pytest.mark.asyncio
@respx.mock
async def test_login_returns_token_pair():
    respx.post(f"{settings.BACKEND_BASE_URL}/auth/login").mock(
        return_value=Response(200, json={"access_token": "a", "refresh_token": "r", "token_type": "bearer"})
    )
    pair = await api_client.login("user@example.com", "pw")
    assert pair.access_token == "a"
    assert pair.refresh_token == "r"


@pytest.mark.asyncio
@respx.mock
async def test_login_401_raises_backend_api_error():
    respx.post(f"{settings.BACKEND_BASE_URL}/auth/login").mock(
        return_value=Response(401, json={"detail": "Incorrect email or password"})
    )
    with pytest.raises(BackendUnauthorizedError):
        await api_client.login("user@example.com", "wrong")


@pytest.mark.asyncio
@respx.mock
async def test_get_product_by_name_404_returns_none():
    respx.get(f"{settings.BACKEND_BASE_URL}/products/nonexistent").mock(return_value=Response(404))
    result = await api_client.get_product_by_name("token", "nonexistent")
    assert result is None


@pytest.mark.asyncio
@respx.mock
async def test_predict_text_sends_portion_size_when_given():
    route = respx.post(f"{settings.BACKEND_BASE_URL}/products/predict-text").mock(
        return_value=Response(200, json={
            "product": {"id": "1", "name": "banana"}, "published": True, "message": "ok",
        })
    )
    await api_client.predict_text("token", "banana", portion_size_g=120.0)
    sent_body = route.calls.last.request.content
    assert b"120.0" in sent_body


@pytest.mark.asyncio
@respx.mock
async def test_analyze_photo_uploads_multipart():
    route = respx.post(f"{settings.BACKEND_BASE_URL}/photo/analyze").mock(
        return_value=Response(201, json={
            "photo": {"id": "p1", "status": "processed", "predicted_label": None,
                      "predicted_confidence": None, "product_id": None, "error_message": None,
                      "created_at": "2026-07-08T00:00:00Z"},
            "product": None, "published": False, "message": "inconclusive",
        })
    )
    result = await api_client.analyze_photo("token", "photo.jpg", b"\xff\xd8\xff", "image/jpeg")
    assert result["published"] is False
    assert route.calls.last.request.headers["authorization"] == "Bearer token"


@pytest.mark.asyncio
@respx.mock
async def test_generic_5xx_raises_backend_api_error_not_unauthorized():
    respx.get(f"{settings.BACKEND_BASE_URL}/diet-phase").mock(return_value=Response(500, json={"detail": "boom"}))
    with pytest.raises(BackendApiError) as exc_info:
        await api_client.get_diet_phase("token")
    assert exc_info.value.status_code == 500
    assert not isinstance(exc_info.value, BackendUnauthorizedError)
