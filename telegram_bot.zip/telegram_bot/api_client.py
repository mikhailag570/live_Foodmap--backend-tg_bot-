"""
api_client.py

Thin async wrapper around the FastAPI backend (live_fodmap_backend/)
built earlier. Every function here maps 1:1 to a backend endpoint and
raises BackendApiError on non-2xx responses so handlers can catch one
exception type.

Kept deliberately free of any Telegram-specific concepts (no aiogram
imports) so it could in principle be reused by a different frontend.
"""
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from config import settings


class BackendApiError(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


class BackendUnauthorizedError(BackendApiError):
    """Raised on 401 - the caller should refresh the access token and retry once."""


@dataclass
class TokenPair:
    access_token: str
    refresh_token: str


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=settings.BACKEND_BASE_URL,
        timeout=settings.BACKEND_HTTP_TIMEOUT_SECONDS,
    )


def _raise_for_error(resp: httpx.Response) -> None:
    if resp.status_code < 400:
        return
    try:
        detail = resp.json().get("detail", resp.text)
    except ValueError:
        detail = resp.text
    if resp.status_code == 401:
        raise BackendUnauthorizedError(resp.status_code, str(detail))
    raise BackendApiError(resp.status_code, str(detail))


def _auth_headers(access_token: str) -> dict:
    return {"Authorization": f"Bearer {access_token}"}


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #

async def register(email: str, password: str, full_name: Optional[str] = None) -> dict:
    async with _client() as client:
        resp = await client.post("/auth/register", json={
            "email": email, "password": password, "full_name": full_name,
        })
        _raise_for_error(resp)
        return resp.json()


async def login(email: str, password: str) -> TokenPair:
    async with _client() as client:
        resp = await client.post("/auth/login", json={"email": email, "password": password})
        _raise_for_error(resp)
        data = resp.json()
        return TokenPair(access_token=data["access_token"], refresh_token=data["refresh_token"])


async def refresh(refresh_token: str) -> TokenPair:
    async with _client() as client:
        resp = await client.post("/auth/refresh", json={"refresh_token": refresh_token})
        _raise_for_error(resp)
        data = resp.json()
        return TokenPair(access_token=data["access_token"], refresh_token=data["refresh_token"])


async def logout(refresh_token: str) -> None:
    async with _client() as client:
        resp = await client.post("/auth/logout", json={"refresh_token": refresh_token})
        if resp.status_code not in (204, 401):  # already-invalid token is fine on logout
            _raise_for_error(resp)


async def me(access_token: str) -> dict:
    async with _client() as client:
        resp = await client.get("/auth/me", headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Products (Task 1: text-based FODMAP prediction)
# --------------------------------------------------------------------------- #

async def get_product_by_name(access_token: str, name: str) -> Optional[dict]:
    async with _client() as client:
        resp = await client.get(f"/products/{name}", headers=_auth_headers(access_token))
        if resp.status_code == 404:
            return None
        _raise_for_error(resp)
        return resp.json()


async def predict_text(access_token: str, query: str, portion_size_g: Optional[float] = None) -> dict:
    payload: dict[str, Any] = {"query": query}
    if portion_size_g is not None:
        payload["portion_size_g"] = portion_size_g
    async with _client() as client:
        resp = await client.post("/products/predict-text", json=payload, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


async def submit_product_manual(access_token: str, **fields) -> dict:
    async with _client() as client:
        resp = await client.post("/products", json=fields, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Photo (Task 2)
# --------------------------------------------------------------------------- #

async def analyze_photo(access_token: str, filename: str, content: bytes, content_type: str) -> dict:
    async with _client() as client:
        resp = await client.post(
            "/photo/analyze",
            headers=_auth_headers(access_token),
            files={"file": (filename, content, content_type)},
        )
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Meals
# --------------------------------------------------------------------------- #

async def add_meal(
    access_token: str,
    meal_type: str,
    quantity_g: float,
    product_id: Optional[str] = None,
    recipe_id: Optional[str] = None,
    notes: Optional[str] = None,
) -> dict:
    payload = {"meal_type": meal_type, "quantity_g": quantity_g}
    if product_id:
        payload["product_id"] = product_id
    if recipe_id:
        payload["recipe_id"] = recipe_id
    if notes:
        payload["notes"] = notes
    async with _client() as client:
        resp = await client.post("/meals", json=payload, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


async def list_meals(access_token: str, limit: int = 20) -> list:
    async with _client() as client:
        resp = await client.get("/meals", params={"limit": limit}, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Symptoms
# --------------------------------------------------------------------------- #

async def add_symptom(access_token: str, symptom_type: str, severity: int, notes: Optional[str] = None) -> dict:
    payload = {"symptom_type": symptom_type, "severity": severity}
    if notes:
        payload["notes"] = notes
    async with _client() as client:
        resp = await client.post("/symptoms", json=payload, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


async def list_symptoms(access_token: str, limit: int = 20) -> list:
    async with _client() as client:
        resp = await client.get("/symptoms", params={"limit": limit}, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Diet phase
# --------------------------------------------------------------------------- #

async def get_diet_phase(access_token: str) -> dict:
    async with _client() as client:
        resp = await client.get("/diet-phase", headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


async def advance_diet_phase(access_token: str, next_reintro_group: Optional[str] = None) -> dict:
    payload = {}
    if next_reintro_group:
        payload["next_reintro_group"] = next_reintro_group
    async with _client() as client:
        resp = await client.post("/diet-phase/advance", json=payload, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


# --------------------------------------------------------------------------- #
# Planner (Task 3)
# --------------------------------------------------------------------------- #

async def generate_plan(access_token: str, preferences: Optional[dict] = None) -> dict:
    payload = {}
    if preferences:
        payload["preferences"] = preferences
    async with _client() as client:
        resp = await client.post("/planner/generate", json=payload, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()


async def list_plans(access_token: str, limit: int = 5) -> list:
    async with _client() as client:
        resp = await client.get("/planner", params={"limit": limit}, headers=_auth_headers(access_token))
        _raise_for_error(resp)
        return resp.json()
