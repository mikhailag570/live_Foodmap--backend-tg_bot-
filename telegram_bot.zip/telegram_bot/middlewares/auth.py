"""
middlewares/auth.py

For every incoming update, looks up the Telegram user's stored backend
tokens and makes sure `data["access_token"]` is valid before the handler
runs - refreshing it via /auth/refresh if it's missing/expired. If the
user has never registered, `data["access_token"]` is left as None and
`data["is_registered"] = False`; handlers that require auth check that
flag and prompt /start instead of failing with a raw 401.

This is the ONLY place that talks to local_storage's token columns -
handlers just receive a ready-to-use access_token.
"""
import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User as TgUser

import api_client
import local_storage
from api_client import BackendApiError

# Refresh proactively if the stored access token expires within this window,
# so we very rarely hit a live 401 mid-request.
_REFRESH_SKEW = timedelta(minutes=2)


class BackendAuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user: TgUser | None = data.get("event_from_user")
        data["access_token"] = None
        data["is_registered"] = False

        if tg_user is not None:
            record = await asyncio.to_thread(local_storage.get_user, tg_user.id)
            if record is not None and record.access_token:
                data["is_registered"] = True
                access_token = record.access_token

                if self._is_expiring_soon(record.access_token_expires_at):
                    try:
                        pair = await api_client.refresh(record.refresh_token)
                        expires_at = self._compute_expiry_iso()
                        await asyncio.to_thread(
                            local_storage.update_tokens,
                            tg_user.id, pair.access_token, pair.refresh_token, expires_at,
                        )
                        access_token = pair.access_token
                    except BackendApiError:
                        # Refresh token itself is dead - force the user to
                        # re-register rather than silently failing later.
                        data["is_registered"] = False
                        access_token = None

                data["access_token"] = access_token

        return await handler(event, data)

    @staticmethod
    def _is_expiring_soon(expires_at_iso: str | None) -> bool:
        if not expires_at_iso:
            return True
        try:
            expires_at = datetime.fromisoformat(expires_at_iso)
        except ValueError:
            return True
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) + _REFRESH_SKEW >= expires_at

    @staticmethod
    def _compute_expiry_iso(minutes_valid: int = 25) -> str:
        # Slightly under the backend's real 30-minute access-token TTL
        # (see live_fodmap_backend/app/config.py ACCESS_TOKEN_EXPIRE_MINUTES)
        # so the proactive-refresh skew above always has margin.
        return (datetime.now(timezone.utc) + timedelta(minutes=minutes_valid)).isoformat()
