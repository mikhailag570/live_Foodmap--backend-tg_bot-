"""
utils/formatting.py

Pure-stdlib formatting helpers that turn backend JSON responses (plain
dicts, as returned by api_client.py) into Telegram message text. Kept
free of aiogram/httpx imports so this logic is unit-testable without any
third-party packages.
"""
from typing import Optional

_LABEL_EMOJI = {"low": "🟢", "moderate": "🟡", "high": "🔴"}
_LABEL_RU = {"low": "низкий", "moderate": "умеренный", "high": "высокий"}
_STATUS_RU = {
    "predicted": "спрогнозировано ML-моделью",
    "lab_verified": "подтверждено лабораторно",
    "user_submitted": "внесено пользователем (не проверено)",
}
_GROUP_RU = {
    "oligos": "Олигосахариды (фрукто-/галактоолигосахариды)",
    "fructose": "Избыток фруктозы",
    "lactose": "Лактоза",
    "polyols": "Полиолы (сахарные спирты)",
}


def label_emoji(label: str) -> str:
    return _LABEL_EMOJI.get(label, "⚪")


def label_ru(label: str) -> str:
    return _LABEL_RU.get(label, label)


def status_ru(status: str) -> str:
    return _STATUS_RU.get(status, status)


def group_ru(group: str) -> str:
    return _GROUP_RU.get(group, group)


def format_confidence(confidence: float) -> str:
    return f"{confidence * 100:.0f}%"


def format_fodmap_profile(product: dict) -> str:
    """
    product: dict shaped like the backend's ProductOut schema, e.g.
    {
      "name": "...", "portion_size_g": 100.0,
      "oligos_label": "low", "oligos_g": 0.05,
      "fructose_label": "low", "fructose_g": 0.1,
      "lactose_label": "high", "lactose_g": 5.0,
      "polyols_label": "low", "polyols_g": 0.05,
      "overall_label": "high", "confidence": 0.82,
      "status": "predicted",
    }
    """
    lines = [
        f"<b>{_escape(product['name'])}</b>",
        f"Порция: {product['portion_size_g']:.0f} г",
        "",
        f"{label_emoji(product['oligos_label'])} Олигосахариды: {label_ru(product['oligos_label'])}"
        + _grams_suffix(product.get("oligos_g")),
        f"{label_emoji(product['fructose_label'])} Фруктоза: {label_ru(product['fructose_label'])}"
        + _grams_suffix(product.get("fructose_g")),
        f"{label_emoji(product['lactose_label'])} Лактоза: {label_ru(product['lactose_label'])}"
        + _grams_suffix(product.get("lactose_g")),
        f"{label_emoji(product['polyols_label'])} Полиолы: {label_ru(product['polyols_label'])}"
        + _grams_suffix(product.get("polyols_g")),
        "",
        f"{label_emoji(product['overall_label'])} <b>Итог: {label_ru(product['overall_label'])} FODMAP</b>",
        f"Уверенность: {format_confidence(product['confidence'])}",
        f"Статус: {status_ru(product['status'])}",
    ]
    return "\n".join(lines)


def format_publish_notice(published: bool, message: str) -> str:
    if published:
        return f"✅ Продукт добавлен в общий каталог.\n<i>{_escape(message)}</i>"
    return f"⚠️ Продукт сохранён, но требует проверки перед публикацией.\n<i>{_escape(message)}</i>"


def format_meal(meal: dict, product_name: Optional[str] = None) -> str:
    label = product_name or meal.get("product_id") or meal.get("recipe_id") or "?"
    return (
        f"🍽 {meal['meal_type']} · {label} · {meal['quantity_g']:.0f} г\n"
        f"   {meal['eaten_at']}"
    )


def severity_bar(severity: int) -> str:
    severity = max(1, min(10, severity))
    return "🟥" * severity + "⬜" * (10 - severity) + f"  {severity}/10"


def format_symptom(symptom: dict) -> str:
    return (
        f"🩺 {symptom['symptom_type']} — {severity_bar(symptom['severity'])}\n"
        f"   {symptom['recorded_at']}"
    )


def format_diet_phase(phase_state: dict) -> str:
    phase_names = {"elimination": "1. Элиминация", "reintroduction": "2. Реинтродукция",
                    "personalisation": "3. Поддержание"}
    phase = phase_names.get(phase_state["phase"], str(phase_state["phase"]))
    lines = [f"Текущий этап: <b>{phase}</b>", f"С {phase_state['phase_started_at']}"]
    if phase_state.get("current_reintro_group"):
        lines.append(f"Тестируемая группа: {group_ru(phase_state['current_reintro_group'])}")
    if phase_state.get("completed_reintro_groups"):
        done = [group_ru(g) for g in phase_state["completed_reintro_groups"].split(",") if g]
        if done:
            lines.append("Уже протестировано: " + ", ".join(done))
    return "\n".join(lines)


def _grams_suffix(grams) -> str:
    if grams is None:
        return ""
    return f" ({grams:.2f} г/порцию)"


def _escape(text: str) -> str:
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
