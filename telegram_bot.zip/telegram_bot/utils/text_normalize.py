"""
utils/text_normalize.py

Pure-stdlib text normalisation for the "Очистка" step of the product
text-search pipeline (see the pasted pipeline doc: "Текст -> Очистка ->
Поиск похожих названий -> ..."). This runs bot-side, before the query is
sent to the backend's /products/predict-text (the backend's ML text
classifier then does the heavier normalisation/embedding matching).

Deliberately has ZERO third-party imports so it can be unit-tested in
any environment, including this sandbox, without network access.
"""
import re
import unicodedata

_MULTI_SPACE_RE = re.compile(r"\s+")
# Characters we strip outright: punctuation/symbols that never carry
# product-identity meaning for a short food query.
_STRIP_CHARS_RE = re.compile(r"[^\w\s\-]", flags=re.UNICODE)


def normalize_product_query(raw_text: str) -> str:
    """
    "яблоко", "Яблоко", "  ЯБЛОКО  ", "green   apple!" ->
    "яблоко", "яблоко", "яблоко", "green apple"

    Steps:
      1. Unicode NFKC normalisation (so visually-identical characters
         from different input methods compare equal).
      2. Strip surrounding whitespace.
      3. Lowercase (case-insensitive matching).
      4. Drop punctuation/symbols (keeps letters, digits, spaces, hyphens).
      5. Collapse repeated whitespace to a single space.
    """
    if raw_text is None:
        return ""
    text = unicodedata.normalize("NFKC", raw_text)
    text = text.strip().lower()
    text = _STRIP_CHARS_RE.sub(" ", text)
    text = _MULTI_SPACE_RE.sub(" ", text).strip()
    return text


def is_query_too_short(normalized_text: str, min_length: int = 2) -> bool:
    return len(normalized_text) < min_length


def is_query_too_long(normalized_text: str, max_length: int = 200) -> bool:
    return len(normalized_text) > max_length
