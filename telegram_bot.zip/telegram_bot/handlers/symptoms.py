"""handlers/symptoms.py - "🩺 Мои симптомы" flow: log + view symptoms."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from keyboards import BTN_SYMPTOMS, main_menu_kb, severity_kb, symptom_menu_kb, symptom_type_kb
from states import SymptomAdd
from utils.formatting import format_symptom

router = Router(name="symptoms")


@router.message(F.text == BTN_SYMPTOMS)
async def symptoms_menu(message: Message, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer("Симптомы:", reply_markup=symptom_menu_kb())


@router.callback_query(F.data == "symptom:add")
async def symptom_add_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Какой симптом отмечаем?", reply_markup=symptom_type_kb())
    await state.set_state(SymptomAdd.choosing_type)
    await callback.answer()


@router.callback_query(SymptomAdd.choosing_type, F.data.startswith("symptom_type:"))
async def symptom_choose_type(callback: CallbackQuery, state: FSMContext):
    symptom_type = callback.data.split(":", 1)[1]
    await state.update_data(symptom_type=symptom_type)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("Оцените интенсивность от 1 (слабо) до 10 (сильно):", reply_markup=severity_kb())
    await state.set_state(SymptomAdd.choosing_severity)
    await callback.answer()


@router.callback_query(SymptomAdd.choosing_severity, F.data.startswith("severity:"))
async def symptom_choose_severity(callback: CallbackQuery, state: FSMContext, access_token: str):
    severity = int(callback.data.split(":", 1)[1])
    await state.update_data(severity=severity)
    await callback.message.edit_reply_markup(reply_markup=None)

    data = await state.get_data()
    try:
        await api_client.add_symptom(access_token, symptom_type=data["symptom_type"], severity=severity)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await state.clear()
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Не удалось сохранить симптом: {exc.detail}")
        await state.clear()
        await callback.answer()
        return

    await callback.message.answer("✅ Симптом сохранён. Спасибо!", reply_markup=main_menu_kb())
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "symptom:history")
async def symptom_history(callback: CallbackQuery, access_token: str):
    try:
        symptoms = await api_client.list_symptoms(access_token, limit=15)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        await callback.answer()
        return

    if not symptoms:
        await callback.message.answer("Записей о симптомах пока нет.")
    else:
        text = "\n\n".join(format_symptom(s) for s in symptoms)
        await callback.message.answer(f"Последние записи:\n\n{text}")
    await callback.answer()
