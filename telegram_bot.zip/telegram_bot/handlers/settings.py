"""
handlers/settings.py

"⚙️ Настройки" flow: view the locally-stored health profile, view/advance
the backend-tracked diet phase, and "logout" (forget local credentials -
see README for why this is a destructive local-only action).
"""
import asyncio

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import api_client
import local_storage
from api_client import BackendApiError, BackendUnauthorizedError
from keyboards import (
    BTN_SETTINGS,
    confirm_logout_kb,
    fodmap_group_kb,
    main_menu_kb,
    settings_menu_kb,
)
from states import DietPhaseAdvance
from utils.formatting import format_diet_phase

router = Router(name="settings")

_GENDER_RU = {"male": "мужской", "female": "женский", "other": "другое"}


@router.message(F.text == BTN_SETTINGS)
async def settings_menu(message: Message, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer("Настройки:", reply_markup=settings_menu_kb())


@router.callback_query(F.data == "settings:profile")
async def show_profile(callback: CallbackQuery):
    profile = await asyncio.to_thread(local_storage.get_profile, callback.from_user.id)
    if profile is None:
        await callback.message.answer("Профиль не найден, выполните /start заново.")
        await callback.answer()
        return

    lines = [
        f"Возраст: {profile.age}",
        f"Пол: {_GENDER_RU.get(profile.gender, profile.gender)}",
        f"Вес: {profile.weight_kg} кг",
        f"Рост: {profile.height_cm} см",
        f"Диагноз: {profile.diagnosis or '—'}",
        f"Аллергии: {profile.allergies_detail if profile.has_allergies else 'нет'}",
        f"Предпочтения: {profile.preferences or '—'}",
        f"Ограничения: {profile.restrictions or '—'}",
    ]
    await callback.message.answer("\n".join(lines))
    await callback.answer()


@router.callback_query(F.data == "settings:diet_phase")
async def show_diet_phase(callback: CallbackQuery, access_token: str):
    try:
        phase_state = await api_client.get_diet_phase(access_token)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        await callback.answer()
        return

    await callback.message.answer(format_diet_phase(phase_state))

    if phase_state["phase"] in ("elimination", "reintroduction"):
        exclude = set()
        if phase_state.get("completed_reintro_groups"):
            exclude.update(g for g in phase_state["completed_reintro_groups"].split(",") if g)
        if phase_state.get("current_reintro_group"):
            exclude.add(phase_state["current_reintro_group"])
        await callback.message.answer(
            "Перейти к реинтродукции следующей группы (или завершить, если "
            "все 4 уже протестированы):",
            reply_markup=fodmap_group_kb(exclude=frozenset(exclude)),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("group:"))
async def advance_diet_phase_group(callback: CallbackQuery, access_token: str):
    group = callback.data.split(":", 1)[1]
    try:
        updated = await api_client.advance_diet_phase(access_token, next_reintro_group=group)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Не удалось перейти к следующей группе: {exc.detail}")
        await callback.answer()
        return

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("✅ Обновлено:\n\n" + format_diet_phase(updated))
    await callback.answer()


@router.callback_query(F.data == "settings:logout")
async def logout_prompt(callback: CallbackQuery):
    await callback.message.answer(
        "⚠️ Это удалит локально сохранённые токены и профиль. История в самом "
        "бэкенде (продукты, дневник, симптомы) не удаляется. Продолжить?",
        reply_markup=confirm_logout_kb(),
    )
    await callback.answer()


@router.callback_query(F.data == "logout:cancel")
async def logout_cancel(callback: CallbackQuery):
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("Отменено.", reply_markup=main_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "logout:confirm")
async def logout_confirm(callback: CallbackQuery, state: FSMContext):
    record = await asyncio.to_thread(local_storage.get_user, callback.from_user.id)
    if record and record.refresh_token:
        try:
            await api_client.logout(record.refresh_token)
        except BackendApiError:
            pass  # best-effort; we still forget local state below

    await asyncio.to_thread(local_storage.delete_user, callback.from_user.id)
    await state.clear()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        "Вы вышли. Напишите /start, чтобы зарегистрироваться заново.",
    )
    await callback.answer()
