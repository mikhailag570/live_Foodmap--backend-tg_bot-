"""
handlers/diary.py

"📔 Мой дневник" flow: add a meal (looked up by product name against the
backend catalogue) and view meal history. Per the pipeline doc
("Через несколько часов бот напоминает: Оцените симптомы"), successfully
logging a meal schedules a delayed reminder.
"""
import asyncio

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from config import settings
from keyboards import BTN_DIARY, diary_menu_kb, main_menu_kb, meal_type_kb, symptom_menu_kb
from states import DiaryAddMeal
from utils.formatting import format_meal
from utils.text_normalize import normalize_product_query

router = Router(name="diary")


@router.message(F.text == BTN_DIARY)
async def diary_menu(message: Message, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer("Дневник питания:", reply_markup=diary_menu_kb())


@router.callback_query(F.data == "diary:add")
async def diary_add_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Что вы съели? Напишите название продукта.")
    await state.set_state(DiaryAddMeal.waiting_product_query)
    await callback.answer()


@router.message(DiaryAddMeal.waiting_product_query)
async def diary_add_lookup_product(message: Message, state: FSMContext, access_token: str):
    normalized = normalize_product_query(message.text or "")
    if not normalized:
        await message.answer("Название не должно быть пустым, попробуйте ещё раз.")
        return

    try:
        product = await api_client.get_product_by_name(access_token, normalized)
    except BackendUnauthorizedError:
        await message.answer("Сессия истекла, выполните /start заново.")
        await state.clear()
        return
    except BackendApiError as exc:
        await message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        return

    if product is None:
        await message.answer(
            "Такого продукта пока нет в базе. Сначала найдите его через "
            "«🔍 Определить продукт», затем вернитесь в дневник.",
            reply_markup=main_menu_kb(),
        )
        await state.clear()
        return

    await state.update_data(product_id=product["id"], product_name=product["name"])
    await message.answer(f"Продукт: {product['name']}. Когда вы это ели?", reply_markup=meal_type_kb())
    await state.set_state(DiaryAddMeal.choosing_meal_type)


@router.callback_query(DiaryAddMeal.choosing_meal_type, F.data.startswith("meal_type:"))
async def diary_add_meal_type(callback: CallbackQuery, state: FSMContext):
    meal_type = callback.data.split(":", 1)[1]
    await state.update_data(meal_type=meal_type)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("Сколько грамм примерно вы съели? (число, например 150)")
    await state.set_state(DiaryAddMeal.waiting_quantity)
    await callback.answer()


@router.message(DiaryAddMeal.waiting_quantity)
async def diary_add_quantity(message: Message, state: FSMContext, access_token: str):
    try:
        quantity = float((message.text or "").strip().replace(",", "."))
        if quantity <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Введите положительное число граммов, например: 150")
        return

    data = await state.get_data()
    try:
        meal = await api_client.add_meal(
            access_token,
            meal_type=data["meal_type"],
            quantity_g=quantity,
            product_id=data["product_id"],
        )
    except BackendUnauthorizedError:
        await message.answer("Сессия истекла, выполните /start заново.")
        await state.clear()
        return
    except BackendApiError as exc:
        await message.answer(f"⚠️ Не удалось сохранить приём пищи: {exc.detail}")
        await state.clear()
        return

    await message.answer("✅ Приём пищи сохранён в дневнике.", reply_markup=main_menu_kb())
    await state.clear()

    # Pipeline doc: "Через несколько часов бот напоминает: Оцените симптомы".
    asyncio.create_task(_schedule_symptom_reminder(message))


@router.callback_query(F.data == "diary:history")
async def diary_history(callback: CallbackQuery, access_token: str):
    try:
        meals = await api_client.list_meals(access_token, limit=15)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        await callback.answer()
        return

    if not meals:
        await callback.message.answer("Дневник пока пуст.")
    else:
        text = "\n\n".join(format_meal(m) for m in meals)
        await callback.message.answer(f"Последние записи:\n\n{text}")
    await callback.answer()


async def _schedule_symptom_reminder(message: Message) -> None:
    """
    Fire-and-forget in-process delay. Fine for a small/single-instance
    deployment; for production with multiple workers or restarts, replace
    with a persistent scheduler (APScheduler + a DB jobstore, or a Celery/
    RQ task) so reminders survive a process restart - see README
    "Известные ограничения".
    """
    await asyncio.sleep(settings.SYMPTOM_REMINDER_DELAY_MINUTES * 60)
    try:
        await message.answer(
            "⏰ Как самочувствие после последнего приёма пищи? "
            "Оцените симптомы от 1 до 10.",
            reply_markup=symptom_menu_kb(),
        )
    except Exception:
        # Bot may have been stopped/blocked by the user since scheduling -
        # a failed reminder should never crash the process.
        pass
