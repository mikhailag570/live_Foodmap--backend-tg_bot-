"""
handlers/product_text.py

"🔍 Определить продукт" flow, implementing the pipeline from the pasted
doc: normalise -> ask backend to look it up (backend itself does the
"search known products -> else ML model + confidence -> predicted"
pipeline) -> show the FODMAP profile with confidence/status.
"""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from keyboards import BTN_FIND_PRODUCT, main_menu_kb
from states import ProductTextSearch
from utils.formatting import format_fodmap_profile, format_publish_notice
from utils.text_normalize import is_query_too_long, is_query_too_short, normalize_product_query

router = Router(name="product_text")


@router.message(F.text == BTN_FIND_PRODUCT)
async def start_product_search(message: Message, state: FSMContext, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer(
        "Напишите название продукта (например, «яблоко» или «apple»)."
    )
    await state.set_state(ProductTextSearch.waiting_query)


@router.message(ProductTextSearch.waiting_query)
async def handle_product_query(message: Message, state: FSMContext, access_token: str):
    raw_query = message.text or ""
    normalized = normalize_product_query(raw_query)

    if is_query_too_short(normalized):
        await message.answer("Слишком короткий запрос, уточните название продукта.")
        return
    if is_query_too_long(normalized):
        await message.answer("Слишком длинный запрос, сократите название продукта.")
        return

    await message.answer("🔎 Ищу в базе...")

    # Step 1 of the pipeline: look in the existing catalogue first.
    try:
        existing = await api_client.get_product_by_name(access_token, normalized)
    except BackendUnauthorizedError:
        await message.answer("Сессия истекла, выполните /start заново.")
        await state.clear()
        return
    except BackendApiError as exc:
        await message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        return

    if existing is not None:
        await message.answer(format_fodmap_profile(existing), reply_markup=main_menu_kb())
        await state.clear()
        return

    # Step 2: not found -> ask the ML text model, confidence-gated by the backend.
    await message.answer("Не нашла точное совпадение, спрашиваю ML-модель...")
    try:
        result = await api_client.predict_text(access_token, normalized)
    except BackendUnauthorizedError:
        await message.answer("Сессия истекла, выполните /start заново.")
        await state.clear()
        return
    except BackendApiError as exc:
        if exc.status_code == 422:
            await message.answer(
                f"🤷 {exc.detail}\n\nПопробуйте описать продукт иначе или введите его "
                "данные вручную через администратора.",
                reply_markup=main_menu_kb(),
            )
        else:
            await message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        await state.clear()
        return

    await message.answer(format_fodmap_profile(result["product"]))
    await message.answer(
        format_publish_notice(result["published"], result["message"]),
        reply_markup=main_menu_kb(),
    )
    await state.clear()
