"""
handlers/product_photo.py

"📷 Распознать по фото" flow. Telegram already does basic image-quality
gating implicitly (users send real camera photos), but we still guard
on file size; the deeper quality/detection/classification/OCR pipeline
described in the doc lives entirely in the backend's ML vision module
(app/ml/photo_classifier.py) - this handler's job is just: download the
photo bytes from Telegram, forward them to POST /photo/analyze, and
render whatever confidence-gated result comes back.
"""
from aiogram import F, Router
from aiogram.types import Message

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from config import settings
from keyboards import BTN_PHOTO, main_menu_kb
from utils.formatting import format_fodmap_profile, format_publish_notice

router = Router(name="product_photo")


@router.message(F.text == BTN_PHOTO)
async def prompt_photo(message: Message, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer("📸 Пришлите фото продукта или его упаковки одним сообщением.")


@router.message(F.photo)
async def handle_photo(message: Message, access_token: str, is_registered: bool):
    if not is_registered or not access_token:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return

    largest_photo = message.photo[-1]  # aiogram returns sizes ascending; last = biggest
    if largest_photo.file_size and largest_photo.file_size > settings.MAX_PHOTO_DOWNLOAD_MB * 1024 * 1024:
        await message.answer(f"Фото слишком большое (лимит {settings.MAX_PHOTO_DOWNLOAD_MB} МБ).")
        return

    await message.answer("🔍 Анализирую фото...")

    file = await message.bot.get_file(largest_photo.file_id)
    photo_bytes_io = await message.bot.download_file(file.file_path)
    photo_bytes = photo_bytes_io.read()

    try:
        result = await api_client.analyze_photo(
            access_token, filename="photo.jpg", content=photo_bytes, content_type="image/jpeg"
        )
    except BackendUnauthorizedError:
        await message.answer("Сессия истекла, выполните /start заново.")
        return
    except BackendApiError as exc:
        await message.answer(f"⚠️ Не удалось обработать фото: {exc.detail}")
        return

    if result.get("product") is None:
        await message.answer(
            f"🤷 {result['message']}\n\nПопробуйте сделать более чёткое фото или "
            "воспользуйтесь «🔍 Определить продукт» и введите название вручную.",
            reply_markup=main_menu_kb(),
        )
        return

    await message.answer(format_fodmap_profile(result["product"]))
    await message.answer(
        format_publish_notice(result["published"], result["message"]),
        reply_markup=main_menu_kb(),
    )
