"""
handlers/start.py

/start -> registration (age, gender, weight, height, diagnosis,
allergies, preferences, restrictions, diet phase) -> main menu.

On successful collection of all fields, we:
  1. Auto-register a backend account for this Telegram user (synthetic
     email + random password - see README "Известные ограничения": the
     backend has no native "Telegram login", so the bot manages its own
     backend credentials transparently to the human user).
  2. Log in to get an access/refresh token pair.
  3. Store both the backend credentials/tokens and the extended health
     profile in local_storage.py.
  4. If the user says they're already in phase 2 or 3 rather than
     starting fresh at phase 1 (the backend's default for a new
     account), drive the backend's /diet-phase/advance state machine
     accordingly (see comments inline - phase 3 cannot be jumped to
     directly without completing phase 2 first; this is a deliberate
     backend invariant, not a bug).
"""
import asyncio
import secrets

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import api_client
import local_storage
from api_client import BackendApiError
from keyboards import (
    diet_phase_choice_kb,
    fodmap_group_kb,
    gender_kb,
    main_menu_kb,
    yes_no_kb,
)
from states import Registration

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, is_registered: bool):
    await state.clear()

    if is_registered:
        await message.answer(
            "С возвращением! Выберите действие в меню ниже.",
            reply_markup=main_menu_kb(),
        )
        return

    await message.answer(
        "Привет! Я помогу вести Low-FODMAP дневник, находить продукты и "
        "строить план питания.\n\nДавайте зарегистрируемся. Сколько вам лет?"
    )
    await state.set_state(Registration.age)


@router.message(Registration.age)
async def reg_age(message: Message, state: FSMContext):
    if not message.text or not message.text.strip().isdigit():
        await message.answer("Пожалуйста, введите возраст числом, например: 29")
        return
    age = int(message.text.strip())
    if not 10 <= age <= 100:
        await message.answer("Введите реалистичный возраст (10–100).")
        return
    await state.update_data(age=age)
    await message.answer("Укажите ваш пол:", reply_markup=gender_kb())
    await state.set_state(Registration.gender)


@router.callback_query(Registration.gender, F.data.startswith("gender:"))
async def reg_gender(callback: CallbackQuery, state: FSMContext):
    gender = callback.data.split(":", 1)[1]
    await state.update_data(gender=gender)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("Ваш вес (кг)?")
    await state.set_state(Registration.weight)
    await callback.answer()


@router.message(Registration.weight)
async def reg_weight(message: Message, state: FSMContext):
    weight = _parse_positive_float(message.text)
    if weight is None:
        await message.answer("Введите вес числом в кг, например: 61.5")
        return
    await state.update_data(weight_kg=weight)
    await message.answer("Ваш рост (см)?")
    await state.set_state(Registration.height)


@router.message(Registration.height)
async def reg_height(message: Message, state: FSMContext):
    height = _parse_positive_float(message.text)
    if height is None:
        await message.answer("Введите рост числом в см, например: 167")
        return
    await state.update_data(height_cm=height)
    await message.answer(
        "Есть ли у вас диагноз (например, СРК/IBS)? Опишите в свободной форме "
        "или напишите «нет»."
    )
    await state.set_state(Registration.diagnosis)


@router.message(Registration.diagnosis)
async def reg_diagnosis(message: Message, state: FSMContext):
    await state.update_data(diagnosis=message.text.strip())
    await message.answer("Есть ли у вас пищевые аллергии?", reply_markup=yes_no_kb("allerg"))
    await state.set_state(Registration.allergies_yes_no)


@router.callback_query(Registration.allergies_yes_no, F.data.startswith("allerg:"))
async def reg_allergies_yes_no(callback: CallbackQuery, state: FSMContext):
    answer = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup(reply_markup=None)
    if answer == "yes":
        await callback.message.answer("Какие именно? Перечислите через запятую.")
        await state.set_state(Registration.allergies_detail)
    else:
        await state.update_data(has_allergies=False, allergies_detail=None)
        await callback.message.answer(
            "Есть ли пищевые предпочтения (вегетарианство, халяль и т.п.)? "
            "Напишите или «нет»."
        )
        await state.set_state(Registration.preferences)
    await callback.answer()


@router.message(Registration.allergies_detail)
async def reg_allergies_detail(message: Message, state: FSMContext):
    await state.update_data(has_allergies=True, allergies_detail=message.text.strip())
    await message.answer(
        "Есть ли пищевые предпочтения (вегетарианство, халяль и т.п.)? "
        "Напишите или «нет»."
    )
    await state.set_state(Registration.preferences)


@router.message(Registration.preferences)
async def reg_preferences(message: Message, state: FSMContext):
    await state.update_data(preferences=message.text.strip())
    await message.answer("Есть ли ограничения по продуктам (не считая FODMAP)? Напишите или «нет».")
    await state.set_state(Registration.restrictions)


@router.message(Registration.restrictions)
async def reg_restrictions(message: Message, state: FSMContext):
    await state.update_data(restrictions=message.text.strip())
    await message.answer(
        "На каком этапе Low-FODMAP диеты вы находитесь?",
        reply_markup=diet_phase_choice_kb(),
    )
    await state.set_state(Registration.diet_phase_choice)


@router.callback_query(Registration.diet_phase_choice, F.data.startswith("phase:"))
async def reg_diet_phase_choice(callback: CallbackQuery, state: FSMContext):
    phase = callback.data.split(":", 1)[1]  # elimination | reintroduction | personalisation
    await state.update_data(diet_phase_choice=phase)
    await callback.message.edit_reply_markup(reply_markup=None)

    if phase == "reintroduction":
        await callback.message.answer(
            "С какой группы FODMAP начнём реинтродукцию?",
            reply_markup=fodmap_group_kb(),
        )
        await state.set_state(Registration.diet_phase_start_group)
        await callback.answer()
        return

    if phase == "personalisation":
        # NOTE (intentional limitation, see README "Известные ограничения"):
        # the backend's phase state machine only allows 1->2->3 in order
        # (2->3 requires all 4 groups already challenged), so a brand-new
        # user cannot be dropped straight into phase 3 via the API as-is.
        # We register them at phase 1 (the backend default) and tell them
        # honestly what happened, instead of silently pretending it worked.
        await callback.message.answer(
            "Приняла к сведению, что вы уже на этапе поддержания. Из-за того, "
            "как сейчас устроен бэкенд, новый профиль всегда стартует с "
            "этапа 1 (элиминация) - двигаться по этапам можно будет через "
            "«⚙️ Настройки → Этап диеты». Если для вас это важно, дайте знать - "
            "это можно донастроить на стороне сервера."
        )

    await _finish_registration(callback.message, state, callback.from_user.id)
    await callback.answer()


@router.callback_query(Registration.diet_phase_start_group, F.data.startswith("group:"))
async def reg_diet_phase_start_group(callback: CallbackQuery, state: FSMContext):
    group = callback.data.split(":", 1)[1]
    await state.update_data(diet_phase_start_group=group)
    await callback.message.edit_reply_markup(reply_markup=None)
    await _finish_registration(callback.message, state, callback.from_user.id)
    await callback.answer()


async def _finish_registration(message: Message, state: FSMContext, telegram_id: int) -> None:
    data = await state.get_data()

    email = f"tg-{telegram_id}@livefodmap.bot"
    password = secrets.token_urlsafe(24)

    try:
        user = await api_client.register(email=email, password=password, full_name=None)
        tokens = await api_client.login(email=email, password=password)
    except BackendApiError as exc:
        await message.answer(
            "⚠️ Не удалось создать профиль на сервере "
            f"(бэкенд ответил: {exc.detail}). Проверьте, что backend запущен "
            "и доступен по BACKEND_BASE_URL, затем повторите /start."
        )
        await state.clear()
        return

    expires_at = _access_token_expiry_iso()
    await asyncio.to_thread(
        local_storage.create_user,
        telegram_id, user["id"], email, password,
        tokens.access_token, tokens.refresh_token, expires_at,
    )
    await asyncio.to_thread(
        local_storage.save_profile,
        local_storage.ProfileRecord(
            telegram_id=telegram_id,
            age=data.get("age"),
            gender=data.get("gender"),
            weight_kg=data.get("weight_kg"),
            height_cm=data.get("height_cm"),
            diagnosis=data.get("diagnosis"),
            has_allergies=data.get("has_allergies", False),
            allergies_detail=data.get("allergies_detail"),
            preferences=data.get("preferences"),
            restrictions=data.get("restrictions"),
        ),
    )

    if data.get("diet_phase_choice") == "reintroduction" and data.get("diet_phase_start_group"):
        try:
            await api_client.advance_diet_phase(
                tokens.access_token, next_reintro_group=data["diet_phase_start_group"]
            )
        except BackendApiError as exc:
            await message.answer(f"⚠️ Не удалось выставить этап реинтродукции: {exc.detail}")

    await state.clear()
    await message.answer(
        "✅ Регистрация завершена! Вот главное меню:",
        reply_markup=main_menu_kb(),
    )


def _parse_positive_float(text: str | None) -> float | None:
    if not text:
        return None
    try:
        value = float(text.strip().replace(",", "."))
    except ValueError:
        return None
    return value if value > 0 else None


def _access_token_expiry_iso(minutes_valid: int = 25) -> str:
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc) + timedelta(minutes=minutes_valid)).isoformat()
