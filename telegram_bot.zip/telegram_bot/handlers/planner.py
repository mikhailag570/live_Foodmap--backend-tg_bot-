"""handlers/planner.py - "📅 План питания" flow: generate + view plans."""
from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

import api_client
from api_client import BackendApiError, BackendUnauthorizedError
from keyboards import BTN_PLANNER, planner_menu_kb

router = Router(name="planner")

_DAY_RU = {
    "monday": "Понедельник", "tuesday": "Вторник", "wednesday": "Среда",
    "thursday": "Четверг", "friday": "Пятница", "saturday": "Суббота", "sunday": "Воскресенье",
}
_MEAL_RU = {"breakfast": "Завтрак", "lunch": "Обед", "dinner": "Ужин", "snack": "Перекус"}


@router.message(F.text == BTN_PLANNER)
async def planner_menu(message: Message, is_registered: bool):
    if not is_registered:
        await message.answer("Сначала выполните /start, чтобы зарегистрироваться.")
        return
    await message.answer("План питания:", reply_markup=planner_menu_kb())


@router.callback_query(F.data == "planner:generate")
async def planner_generate(callback: CallbackQuery, access_token: str):
    await callback.message.answer("✨ Генерирую план на неделю с учётом вашего этапа диеты...")
    try:
        plan = await api_client.generate_plan(access_token)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Не удалось сгенерировать план: {exc.detail}")
        await callback.answer()
        return

    await callback.message.answer(_format_plan(plan["plan"]))
    await callback.answer()


@router.callback_query(F.data == "planner:history")
async def planner_history(callback: CallbackQuery, access_token: str):
    try:
        plans = await api_client.list_plans(access_token, limit=3)
    except BackendUnauthorizedError:
        await callback.message.answer("Сессия истекла, выполните /start заново.")
        await callback.answer()
        return
    except BackendApiError as exc:
        await callback.message.answer(f"⚠️ Ошибка бэкенда: {exc.detail}")
        await callback.answer()
        return

    if not plans:
        await callback.message.answer("Планов питания пока нет.")
        await callback.answer()
        return

    for plan in plans:
        await callback.message.answer(f"План от {plan['created_at']}:\n\n" + _format_plan(plan["plan"]))
    await callback.answer()


def _format_plan(plan_dict: dict) -> str:
    slots = plan_dict.get("slots", [])
    by_day: dict[str, list[dict]] = {}
    for slot in slots:
        by_day.setdefault(slot["day"], []).append(slot)

    lines = []
    for day, day_slots in by_day.items():
        lines.append(f"<b>{_DAY_RU.get(day, day)}</b>")
        for slot in day_slots:
            meal_label = _MEAL_RU.get(slot["meal_type"], slot["meal_type"])
            product = slot.get("product_name") or "нет подходящего продукта в каталоге"
            lines.append(f"  {meal_label}: {product}")
        lines.append("")
    return "\n".join(lines).strip()
