"""
local_storage.py

Bot-side local storage, keyed by Telegram user id. Two things live here
that the current backend (live_fodmap_backend/) does not model:

1. The mapping telegram_id -> backend user (email/password we auto-
   generated) + its JWT access/refresh tokens, so the bot can act on the
   user's behalf against the FastAPI backend without asking them to log
   in with an email/password inside Telegram.
2. The extended health-profile fields from the TZ registration flow
   (age, gender, weight, height, diagnosis, allergies, preferences,
   restrictions) - the backend's `User` model intentionally only has
   email/full_name today (see README "Известные ограничения"); a real
   deployment should move this into the backend as a `UserProfile`
   table + endpoint instead of keeping it bot-side.

Uses plain `sqlite3` from the standard library (synchronous) - simple
enough not to need a dependency, and is wrapped so handlers call it via
asyncio.to_thread(...) to avoid blocking the event loop.
"""
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

try:
    # Deferred/optional: this module is deliberately testable even in an
    # environment where pydantic-settings (a third-party dep of config.py)
    # isn't installed - every public function here accepts an explicit
    # db_path override for exactly that reason.
    from config import settings
    _DEFAULT_DB_PATH = settings.LOCAL_DB_PATH
except Exception:  # pragma: no cover - exercised by the offline test suite
    _DEFAULT_DB_PATH = "./telegram_bot_local.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS telegram_users (
    telegram_id INTEGER PRIMARY KEY,
    backend_user_id TEXT,
    backend_email TEXT,
    backend_password TEXT,
    access_token TEXT,
    refresh_token TEXT,
    access_token_expires_at TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telegram_profiles (
    telegram_id INTEGER PRIMARY KEY,
    age INTEGER,
    gender TEXT,
    weight_kg REAL,
    height_cm REAL,
    diagnosis TEXT,
    has_allergies INTEGER,
    allergies_detail TEXT,
    preferences TEXT,
    restrictions TEXT,
    FOREIGN KEY (telegram_id) REFERENCES telegram_users (telegram_id)
);
"""


@dataclass
class TelegramUserRecord:
    telegram_id: int
    backend_user_id: Optional[str]
    backend_email: Optional[str]
    backend_password: Optional[str]
    access_token: Optional[str]
    refresh_token: Optional[str]
    access_token_expires_at: Optional[str]


@dataclass
class ProfileRecord:
    telegram_id: int
    age: Optional[int]
    gender: Optional[str]
    weight_kg: Optional[float]
    height_cm: Optional[float]
    diagnosis: Optional[str]
    has_allergies: Optional[bool]
    allergies_detail: Optional[str]
    preferences: Optional[str]
    restrictions: Optional[str]


def init_db(db_path: Optional[str] = None) -> None:
    with _connect(db_path) as conn:
        conn.executescript(_SCHEMA)


@contextmanager
def _connect(db_path: Optional[str] = None):
    conn = sqlite3.connect(db_path or _DEFAULT_DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def get_user(telegram_id: int, db_path: Optional[str] = None) -> Optional[TelegramUserRecord]:
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT * FROM telegram_users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
    if row is None:
        return None
    return TelegramUserRecord(
        telegram_id=row["telegram_id"],
        backend_user_id=row["backend_user_id"],
        backend_email=row["backend_email"],
        backend_password=row["backend_password"],
        access_token=row["access_token"],
        refresh_token=row["refresh_token"],
        access_token_expires_at=row["access_token_expires_at"],
    )


def create_user(
    telegram_id: int,
    backend_user_id: str,
    backend_email: str,
    backend_password: str,
    access_token: str,
    refresh_token: str,
    access_token_expires_at: str,
    db_path: Optional[str] = None,
) -> None:
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO telegram_users
                (telegram_id, backend_user_id, backend_email, backend_password,
                 access_token, refresh_token, access_token_expires_at, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                backend_user_id=excluded.backend_user_id,
                backend_email=excluded.backend_email,
                backend_password=excluded.backend_password,
                access_token=excluded.access_token,
                refresh_token=excluded.refresh_token,
                access_token_expires_at=excluded.access_token_expires_at
            """,
            (
                telegram_id, backend_user_id, backend_email, backend_password,
                access_token, refresh_token, access_token_expires_at,
                datetime.utcnow().isoformat(),
            ),
        )


def update_tokens(
    telegram_id: int,
    access_token: str,
    refresh_token: str,
    access_token_expires_at: str,
    db_path: Optional[str] = None,
) -> None:
    with _connect(db_path) as conn:
        conn.execute(
            """
            UPDATE telegram_users
            SET access_token = ?, refresh_token = ?, access_token_expires_at = ?
            WHERE telegram_id = ?
            """,
            (access_token, refresh_token, access_token_expires_at, telegram_id),
        )


def delete_user(telegram_id: int, db_path: Optional[str] = None) -> None:
    """Used by the '⚙️ Настройки -> Выйти' flow to forget local credentials/tokens."""
    with _connect(db_path) as conn:
        conn.execute("DELETE FROM telegram_profiles WHERE telegram_id = ?", (telegram_id,))
        conn.execute("DELETE FROM telegram_users WHERE telegram_id = ?", (telegram_id,))


def save_profile(profile: ProfileRecord, db_path: Optional[str] = None) -> None:
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO telegram_profiles
                (telegram_id, age, gender, weight_kg, height_cm, diagnosis,
                 has_allergies, allergies_detail, preferences, restrictions)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                age=excluded.age, gender=excluded.gender, weight_kg=excluded.weight_kg,
                height_cm=excluded.height_cm, diagnosis=excluded.diagnosis,
                has_allergies=excluded.has_allergies, allergies_detail=excluded.allergies_detail,
                preferences=excluded.preferences, restrictions=excluded.restrictions
            """,
            (
                profile.telegram_id, profile.age, profile.gender, profile.weight_kg,
                profile.height_cm, profile.diagnosis,
                int(bool(profile.has_allergies)) if profile.has_allergies is not None else None,
                profile.allergies_detail, profile.preferences, profile.restrictions,
            ),
        )


def get_profile(telegram_id: int, db_path: Optional[str] = None) -> Optional[ProfileRecord]:
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT * FROM telegram_profiles WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
    if row is None:
        return None
    return ProfileRecord(
        telegram_id=row["telegram_id"],
        age=row["age"],
        gender=row["gender"],
        weight_kg=row["weight_kg"],
        height_cm=row["height_cm"],
        diagnosis=row["diagnosis"],
        has_allergies=bool(row["has_allergies"]) if row["has_allergies"] is not None else None,
        allergies_detail=row["allergies_detail"],
        preferences=row["preferences"],
        restrictions=row["restrictions"],
    )
